/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

// SYS
#include "main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "cmsis_os.h"
#include "queue.h"
#include "semphr.h"

// SERIAL
#include "serial.h"
#include <stdio.h>
#include <stdlib.h>

// ALMP
#include "arm_const_structs.h"
#include "arm_math.h"
#include "levmar.h"

// LVGL
#include "lvgl/lvgl.h"
#include "hal_stm_lvgl/tft/tft.h"
#include "hal_stm_lvgl/touchpad/touchpad.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// GAUSSIAN NOISE
#define DBL_RAND_MAX (float)(RAND_MAX)
#define INIT_RANDOM(seed) srandom((int)xTaskGetTickCount()) 		// seed unused
#define STD_NOISE 1e-2

// SIGNAL
#define S_SOURCE 0								// 0 = ADC; 1 = Teste
#define S_PU 1									// 0 = MAGNITUDE; 1 = PU
#define CONS_PI_3  1.04719755120341065132f		// pi/3
#define CONS_T_AM  0.00006510416666666657f		// Ts = 1/15360 = 65,10416667e-6
#define CONS_FS_AM 15360						// Fs = 15360
#define N_CYCLES 12                       		// N_CYCLES   = Fn/Fiec = 60Hz/5Hz
#define N_MEASUREMENTS (N_CYCLES * 256)     	// N_MEASUREMENTS = N_CYCLES*Fs/Fn

// MAGNITUDE
#if (S_PU == 0)
#define S_MAGNITUDE 3.3							// A = S_MAGNITUDE * lm_params[0]
#elif(S_PU == 1)
#define S_MAGNITUDE 1							// A = S_MAGNITUDE * lm_params[0]
#endif

// FFT
#if (N_CYCLES >= 8)
#define N_FFT 2048								// N_FFT <= N_MEASUREMENTS
#define N_FFT_2 1024							// N_FFT_2 = N_FFT / 2
#define N_1_FFT 0.00048828125f					// N_1_FFT = 1 / N_FFT
#elif (N_CYCLES >= 4 && N_CYCLES < 8)
#define N_FFT 1024								// N_FFT <= N_MEASUREMENTS
#define N_FFT_2 512								// N_FFT_2 = N_FFT / 2
#define N_1_FFT 0.0009765625f					// N_1_FFT = 1 / N_FFT
#elif (N_CYCLES >= 2 && N_CYCLES < 4)
#define N_FFT 512								// N_FFT <= N_MEASUREMENTS
#define N_FFT_2 256								// N_FFT_2 = N_FFT / 2
#define N_1_FFT 0.001953125f					// N_1_FFT = 1 / N_FFT
#elif (N_CYCLES >= 1 && N_CYCLES < 2)
#define N_FFT 256								// N_FFT <= N_MEASUREMENTS
#define N_FFT_2 128								// N_FFT_2 = N_FFT / 2
#define N_1_FFT 0.00390625f						// N_1_FFT = 1 / N_FFT
#endif

// ALMP
#define N_PARAMS 3                         	 	// p[0]=A, p[1]=wn, p[2]=phi
#define work_size 4*N_MEASUREMENTS+4*N_PARAMS+N_MEASUREMENTS*N_PARAMS+N_PARAMS*N_PARAMS
#define N_ITER 25								// Maximo de 100 iterações
#define I_TOL (10 * M_SQRT2 * STD_NOISE * STD_NOISE)		// Tolerância
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

//BOOL
uint8_t input_Channel = 0;							// 0 -> ADC1, 1 -> ADC3

//UINT16_T
uint8_t almp_Iter = 1;							// Interação atual do ALMP
uint16_t common_variable = 0;					// TEST -> Binary Semaphore Common Resource
uint16_t ADC_Buffer[N_MEASUREMENTS*3];			// Buffer do ADC atual

//FLOAT32_T
float32_t lm_work_Buffer[work_size];			// Espaço para buffer de trabalho do Levenberg-Marquardt
float32_t signal_Atom[N_MEASUREMENTS];			// Atomo atual extraido do ALMP
float32_t signal_Residue[N_MEASUREMENTS];		// Residuo do sinal original
//float32_t signal_Residue_3[N_MEASUREMENTS];		// Residuo do sinal original
float32_t signal_Reconst[N_MEASUREMENTS];		// Sinal a ser reconstruido com os atomos extraidos
float32_t signal_FFT[N_MEASUREMENTS];			// Sinal da extração da FFT do residuo
float32_t FFT_out_Real[N_FFT_2];				// Parte real da FFT
float32_t FFT_out_Imag[N_FFT_2];				// Parte imaginaria da FFT
float32_t almp_atom_A[N_ITER];					// Amplitude do sinal extraido do ALMP
float32_t almp_atom_F[N_ITER];					// Frequencia do sinal extraido do ALMP
float32_t almp_atom_P[N_ITER];					// Fase do sinal extraido do ALMP
float32_t almp=0;

uint16_t tickDuring=0;
uint8_t singlewindow=0;

//HANDLES STM32
TIM_HandleTypeDef htim8;
ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;
ADC_HandleTypeDef hadc3;
DMA_HandleTypeDef hdma_adc1;

//HANDLES FREERTOS
xSemaphoreHandle bs1;
xSemaphoreHandle bs2;
xSemaphoreHandle bs3;
xSemaphoreHandle s_ALMP_Graph;
xSemaphoreHandle s_ALMP_Text;
xSemaphoreHandle s_LVGL_Graph;
xSemaphoreHandle s_LVGL_Text;
xSemaphoreHandle s_LVGL_Text;
xQueueHandle qADC;

//THREADS
osThreadId_t ALMP_Task_Handle;
osThreadId_t LVGL_Task_Handle;
osThreadId_t BinarySemaphoreTask01_Handle;
osThreadId_t BinarySemaphoreTask02_Handle;
osThreadId_t BinarySemaphoreTask03_Handle;

/* Definitions for ALMP_Task */
/* Definitions for LVGL_Task */
const osThreadAttr_t ALMP_Task_attributes = {
		.name = "ALMP_Task",
		.stack_size = 512 * 4,
		.priority = (osPriority_t) osPriorityRealtime6,
};
const osThreadAttr_t LVGL_Task_attributes = {
		.name = "LVGL_Task",
		.stack_size = 1024 * 4,
		.priority = (osPriority_t) osPriorityRealtime6,
};

/* Definitions for BinarySemaphoreTask01 */
/* Definitions for BinarySemaphoreTask02 */
/* Definitions for BinarySemaphoreTask03 */
const osThreadAttr_t BinarySemaphoreTask01_attributes = {
		.name = "BinarySemaphoreTask01",
		.stack_size = 512 * 2,
		.priority = (osPriority_t) osPriorityRealtime,
};
const osThreadAttr_t BinarySemaphoreTask02_attributes = {
		.name = "BinarySemaphoreTask02",
		.stack_size = 512 * 2,
		.priority = (osPriority_t) osPriorityRealtime,
};
const osThreadAttr_t BinarySemaphoreTask03_attributes = {
		.name = "BinarySemaphoreTask03",
		.stack_size = 512 * 2,
		.priority = (osPriority_t) osPriorityRealtime,
};


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/

// SYS
static void SystemClock_Config(void);
static void MX_TIM8_Init(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_ADC2_Init(void);
static void MX_ADC3_Init(void);
static void MX_DMA_Init(void);

// ALMP
void lm_func_cos_dif(float *p, float *x, int m, int n, void *data);
void lm_jacb_cos_der(float *p, float *jac, int m, int n, void *data);

// LVGL
void lv_gui();

// GAUSSIAN NOISE
float gNoise(float m, float s);

// TASKS
void ALMP_Task(void *argument);
void LVGL_Task(void *argument);
void BinarySemaphoreTask01(void *argument);
void BinarySemaphoreTask02(void *argument);
void BinarySemaphoreTask03(void *argument);

/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{
	//BSP_EEPROM_Init();
	//BSP_SDRAM_Init();

	/* USER CODE BEGIN 1 */
	/* Enable I-Cache---------------------------------------------------------*/
	SCB_EnableICache();
	/* Enable D-Cache---------------------------------------------------------*/
	SCB_EnableDCache();
	/* USER CODE END 1 */

	/* USER CODE BEGIN Init */
	/* MCU Configuration--------------------------------------------------------*/
	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();
	/* USER CODE END Init */

	/* USER CODE BEGIN SysInit */
	/* Configure the system clock */
	SystemClock_Config();
	/* USER CODE END SysInit */

	/* USER CODE BEGIN 2 */
	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_DMA_Init();
	MX_TIM8_Init();
	/* USER CODE END 2 */

	/* Init scheduler */
	osKernelInitialize();

	/* USER CODE BEGIN RTOS_MUTEX */
	/* add mutexes, ... */
	/* USER CODE END RTOS_MUTEX */

	/* USER CODE BEGIN RTOS_SEMAPHORES */
	//	bs1 = xSemaphoreCreateBinary();
	//	xSemaphoreGive(bs1);
	//	bs2 = xSemaphoreCreateBinary();
	//	xSemaphoreGive(bs2);
	//	bs3 = xSemaphoreCreateBinary();
	//	xSemaphoreGive(bs3);
	s_ALMP_Graph = xSemaphoreCreateBinary();
	xSemaphoreGive(s_ALMP_Graph);
	s_ALMP_Text = xSemaphoreCreateBinary();
	xSemaphoreGive(s_ALMP_Text);
	s_LVGL_Graph = xSemaphoreCreateBinary();
	xSemaphoreGive(s_LVGL_Graph);
	s_LVGL_Text = xSemaphoreCreateBinary();
	xSemaphoreGive(s_LVGL_Text);
	/* USER CODE END RTOS_SEMAPHORES */

	/* USER CODE BEGIN RTOS_TIMERS */
	/* start timers, add new ones, ... */
	/* USER CODE END RTOS_TIMERS */

	/* USER CODE BEGIN RTOS_QUEUES */
	/* add queues, ... */
	/* USER CODE END RTOS_QUEUES */


	/* USER CODE BEGIN RTOS_THREADS */

	/* Create the thread(s) */
	/* creation of BinarySemaphoreTask Test*/
	//	BinarySemaphoreTask01_Handle = osThreadNew(BinarySemaphoreTask01, NULL, &BinarySemaphoreTask01_attributes);
	//	BinarySemaphoreTask02_Handle = osThreadNew(BinarySemaphoreTask02, NULL, &BinarySemaphoreTask02_attributes);
	//	BinarySemaphoreTask03_Handle = osThreadNew(BinarySemaphoreTask03, NULL, &BinarySemaphoreTask03_attributes);

	// ALMP_Task
	ALMP_Task_Handle = osThreadNew(ALMP_Task, NULL, &ALMP_Task_attributes);
	// LVGL_Task
	LVGL_Task_Handle = osThreadNew(LVGL_Task, NULL, &LVGL_Task_attributes);

	/* USER CODE END RTOS_THREADS */

	/* USER CODE BEGIN RTOS_EVENTS */
	/* add events, ... */
	/* USER CODE END RTOS_EVENTS */

	/* Start scheduler */
	osKernelStart();

	/* We should never get here as control is now taken by the scheduler */
	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1)
	{
		/* USER CODE BEGIN 3 */
		/* USER CODE END 3 */
		/* USER CODE END WHILE */
	}
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
static void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };
	/** Configure the main internal regulator output voltage
	 */
	__HAL_RCC_PWR_CLK_ENABLE();
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLM = 25;
	RCC_OscInitStruct.PLL.PLLN = 432;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
	RCC_OscInitStruct.PLL.PLLQ = 2;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}
	/** Activate the Over-Drive mode
	 */
	if (HAL_PWREx_EnableOverDrive() != HAL_OK) {
		Error_Handler();
	}
	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_7) != HAL_OK) {
		Error_Handler();
	}
}

/**
 * @brief TIM8 Initialization Function
 * @param None
 * @retval None
 * Frequencia do clock de entrada: 108MHz
 */
static void MX_TIM8_Init(void) {
	/* USER CODE BEGIN TIM8_Init 0 */
	/* USER CODE END TIM8_Init 0 */
	TIM_ClockConfigTypeDef sClockSourceConfig = { 0 };
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };
	/* USER CODE BEGIN TIM8_Init 1 */
	/* USER CODE END TIM8_Init 1 */
	htim8.Instance = TIM8;
	htim8.Init.Prescaler = 0;
	htim8.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim8.Init.Period = 7031;		// (Freq. do TIM8 / Freq. Amostragem) = (216MHz/2) / 15360MHz = 7031
	htim8.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim8.Init.RepetitionCounter = 0;
	htim8.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
	if (HAL_TIM_Base_Init(&htim8) != HAL_OK) {
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim8, &sClockSourceConfig) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
	sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_ENABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim8, &sMasterConfig) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN TIM8_Init 2 */
	/* USER CODE END TIM8_Init 2 */
}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void) {
	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOH_CLK_ENABLE();
}

/* USER CODE BEGIN 4 */
/**
 * @brief ADC1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_ADC1_Init(void) {
	/* USER CODE BEGIN ADC1_Init 0 */
	/* USER CODE END ADC1_Init 0 */
	//ADC_AnalogWDGConfTypeDef AnalogWDGConfig;
	ADC_ChannelConfTypeDef sConfig = { 0 };
	/* USER CODE BEGIN ADC1_Init 1 */
	/* USER CODE END ADC1_Init 1 */
	/** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
	 */
	hadc1.Instance = ADC1;
	hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	hadc1.Init.Resolution = ADC_RESOLUTION_12B;
	hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
	hadc1.Init.ContinuousConvMode = DISABLE;
	hadc1.Init.DiscontinuousConvMode = DISABLE;
	hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
	hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T8_TRGO;
	hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc1.Init.NbrOfConversion = 1;
	hadc1.Init.DMAContinuousRequests = ENABLE;
	hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	if (HAL_ADC_Init(&hadc1) != HAL_OK) {
		Error_Handler();
	}

	/** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
	 */
	sConfig.Channel = ADC_CHANNEL_0;
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_56CYCLES;
	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
		Error_Handler();
	}

	/**Configure the analog watchdog
	 */
	//	AnalogWDGConfig.WatchdogMode = ADC_ANALOGWATCHDOG_ALL_REG;
	//	AnalogWDGConfig.HighThreshold = 2048;	// 4095b - 3.3V ou 0993b - 0.8v
	//	AnalogWDGConfig.LowThreshold = 1;	// 3103b - 2.5V ou 0001b - 0.0v
	//	AnalogWDGConfig.Channel = ADC_CHANNEL_0;
	//	AnalogWDGConfig.ITMode = DISABLE;
	//	if (HAL_ADC_AnalogWDGConfig(&hadc1, &AnalogWDGConfig) != HAL_OK) {
	//		Error_Handler();
	//	}
	/* USER CODE BEGIN ADC1_Init 2 */
	/* USER CODE END ADC1_Init 2 */
}

/* ADC2 init function */
static void MX_ADC2_Init(void) {
	/* USER CODE BEGIN ADC2_Init 0 */
	/* USER CODE END ADC2_Init 0 */
	ADC_ChannelConfTypeDef sConfig;
	/* USER CODE BEGIN ADC2_Init 1 */
	/* USER CODE END ADC2_Init 1 */
	/**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
	 */
	hadc2.Instance = ADC2;
	hadc2.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	hadc2.Init.Resolution = ADC_RESOLUTION_12B;
	hadc2.Init.ScanConvMode = DISABLE;
	hadc2.Init.ContinuousConvMode = DISABLE;
	hadc2.Init.DiscontinuousConvMode = DISABLE;
	hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc2.Init.NbrOfConversion = 1;
	hadc2.Init.DMAContinuousRequests = DISABLE;
	hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	if (HAL_ADC_Init(&hadc2) != HAL_OK) {
		Error_Handler();
	}
	/**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
	 */
	sConfig.Channel = ADC_CHANNEL_4;
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_56CYCLES;
	if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN ADC2_Init 2 */
	/* USER CODE END ADC2_Init 2 */
}

static void MX_ADC3_Init(void) {
	/* USER CODE BEGIN ADC3_Init 0 */
	/* USER CODE END ADC3_Init 0 */
	//ADC_AnalogWDGConfTypeDef AnalogWDGConfig;
	ADC_ChannelConfTypeDef sConfig;
	/* USER CODE BEGIN ADC3_Init 1 */
	/* USER CODE END ADC3_Init 1 */
	/**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
	 */
	hadc3.Instance = ADC3;
	hadc3.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	hadc3.Init.Resolution = ADC_RESOLUTION_12B;
	hadc3.Init.ScanConvMode = DISABLE;
	hadc3.Init.ContinuousConvMode = DISABLE;
	hadc3.Init.DiscontinuousConvMode = DISABLE;
	hadc3.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc3.Init.NbrOfConversion = 1;
	hadc3.Init.DMAContinuousRequests = DISABLE;
	hadc3.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	if (HAL_ADC_Init(&hadc3) != HAL_OK) {
		Error_Handler();
	}

	/**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
	 */
	sConfig.Channel = ADC_CHANNEL_8;
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_56CYCLES;
	if (HAL_ADC_ConfigChannel(&hadc3, &sConfig) != HAL_OK) {
		Error_Handler();
	}

	/**Configure the analog watchdog
	 */
	//	AnalogWDGConfig.WatchdogMode = ADC_ANALOGWATCHDOG_ALL_REG;
	//	AnalogWDGConfig.HighThreshold = 2048;	// 4095b - 3.3V ou 0993b - 0.8v
	//	AnalogWDGConfig.LowThreshold = 1;	// 3103b - 2.5V ou 0001b - 0.0v
	//	AnalogWDGConfig.Channel = ADC_CHANNEL_8;
	//	AnalogWDGConfig.ITMode = DISABLE;
	//	HAL_ADC_AnalogWDGConfig(&hadc3, &AnalogWDGConfig);
	//	if (HAL_ADC_AnalogWDGConfig(&hadc3, &AnalogWDGConfig) != HAL_OK) {
	//		Error_Handler();
	//	}

	/* USER CODE BEGIN ADC3_Init 2 */
	/* USER CODE END ADC3_Init 2 */
}

/**
 * Enable DMA controller clock
 */
static void MX_DMA_Init(void) {
	/* DMA controller clock enable */
	__HAL_RCC_DMA2_CLK_ENABLE();
	/* DMA interrupt init */
	/* DMA2_Stream4_IRQn interrupt configuration */
	HAL_NVIC_SetPriority(DMA2_Stream4_IRQn, 5, 0);
	HAL_NVIC_EnableIRQ(DMA2_Stream4_IRQn);
}

// ADC Half Callback
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc) {
	uint8_t qADC_Buffer = 1;
	signed portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
	xQueueSendToBackFromISR(qADC, &qADC_Buffer, &pxHigherPriorityTaskWoken);
	if (pxHigherPriorityTaskWoken == pdTRUE) {
		portYIELD();
	}
}

// ADC Full Callback
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc) {
	uint8_t qADC_Buffer = 2;
	signed portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
	xQueueSendToBackFromISR(qADC, &qADC_Buffer, &pxHigherPriorityTaskWoken);
	if (pxHigherPriorityTaskWoken == pdTRUE) {
		portYIELD();
	}
}

// GAUSSIAN NOISE
float gNoise(float m, float s) {
	float r1, r2, val;
	r1=((float)random())/DBL_RAND_MAX;
	r2=((float)random())/DBL_RAND_MAX;
	val=sqrt(-2.0*logf(r1))*arm_cos_f32(2.0*M_PI*r2);
	val=s*val+m;
	return val;
}

// LEVENBERG-MARQUARDT FUNCTION
void lm_func_cos_dif(float *p, float *x, int m, int n, void *data){
	register int i;
	for(i=0; i<n; ++i){
		x[i]=p[0]*arm_cos_f32(p[1]*(float)CONS_T_AM*i+p[2]); // ((float)((float *)data)[i]) -
	}
}

// LEVENBERG-MARQUARDT JACOBIAN
void lm_jacb_cos_der(float *p, float *jac, int m, int n, void *data){
	register int i, j;
	for(i=j=0; i<n; ++i) {
		jac[j++]=arm_cos_f32(p[1]*(float)CONS_T_AM*i+p[2]);
		jac[j++]=-p[0]*(float)CONS_T_AM*i*arm_sin_f32(p[1]*(float)CONS_T_AM*i+p[2]);
		jac[j++]=-p[0]*arm_sin_f32(p[1]*(float)CONS_T_AM*i+p[2]);
	}
}

// Tarefa de processamento do algoritmo ALMP
void ALMP_Task(void *argument) {

	/* ADC_Input
	 *		ADC1 -> PA0 	-> A0  -> Voltage
	 *		ADC2 -> PA4		-> --
	 *		ADC3 -> PF11	-> A1  -> Current
	 */



	UARTInit();
	UARTPutString(STDOUT, "\033[2J\033[H",0);
	char buffer[256];

	// Init ADCs
	MX_ADC1_Init();
	MX_ADC2_Init();
	MX_ADC3_Init();

	// Start ADCs
	HAL_ADC_Start(&hadc3);
	HAL_ADC_Start(&hadc2);
	HAL_ADCEx_MultiModeStart_DMA(&hadc1, (uint32_t*) ADC_Buffer, N_MEASUREMENTS * 3);
	HAL_TIM_Base_Start(&htim8);

	//UINT16_T
	uint16_t qADC_Buffer = 0;					// Indice de conversão do ADC usado em fila
	uint16_t signal_Indx = 0;					// Indice dos vetores de sinais
	uint16_t FFT_out_Indx = 0;					// Indice da amplitude maxima do sinal da FFT

	//FLOAT16_T
	float32_t sum_sq_Atom = 0.0;				// Energia do atomo atual ao quadrado
	float32_t sum_sq_Input = 0.0;				// Energia do sinal original ao quadrado
	float32_t sum_sq_Residue = 0.0;				// Energia do sinal do residuo atual ao quadrado
	float32_t sum_sq_Reconst = 0.0;				// Energia do sinal reconstruido atual ao quadrado
	float32_t FFT_out_Mag = 0.0;				// Magnitude atual do sinal da FFT
	float32_t FFT_out_Max = 0.0;				// Magnitude maxima do sinal da FFT

#ifdef _LEVMAR_H_
	float32_t lm_opts[LM_OPTS_SZ];				// Parametros de otimização do Levenberg-Marquardt
	float32_t lm_info[LM_INFO_SZ];				// Informações de execução do Levenberg-Marquardt
#endif

	float32_t lm_params[N_PARAMS];				// Parametros do Levenberg-Marquardt

	float32_t energy_iter_Atom[N_ITER];			// Vetor de energia dos atomos de cada iteração
	float32_t energy_iter_Residue[N_ITER];		// Vetor de energia dos residuos de cada iteração

	qADC = xQueueCreate(1, sizeof(uint32_t));  	// Fila do ADC

	while (1) {
		// Recebe indice de conversão da fila do ADC
		xQueueReceive(qADC, &qADC_Buffer, portMAX_DELAY);

		switch (qADC_Buffer) {
		case 1:		// Meia conversão do ADC
			break;

		case 2: 	// Conversão completa do ADC

			signal_Indx = 0;
			sum_sq_Input = 0.0;
			sum_sq_Residue = 0.0;
#if(S_SOURCE==0)	// Sinal do ADC
			for (uint16_t adc_idx = 0; adc_idx <= 3 * (N_MEASUREMENTS - 1); adc_idx += 3) {
				if(input_Channel == 0)
					signal_Residue[signal_Indx] = ADC_Buffer[adc_idx];		// Canal 1 do ADC
				else if	(input_Channel == 1)
					signal_Residue[signal_Indx] = ADC_Buffer[adc_idx + 2];	// Canal 3 do ADC

				// 1/4096 = 0.000244140625
				signal_Residue[signal_Indx] *= 0.000244140625;	// 0b a 4095b -> 0pu a 1pu
				signal_Residue[signal_Indx] -= 0.5;				// 0pu a 1pu -> -0.5pu a 0.5pu
				signal_Residue[signal_Indx] *= 2.0;				// -0.5pu a 0.5pu -> -1pu a 1pu

				sum_sq_Input += signal_Residue[signal_Indx] * signal_Residue[signal_Indx];
				signal_Reconst[signal_Indx] = 0.0;
				signal_FFT[signal_Indx] = signal_Residue[signal_Indx];

				if(signal_Indx<N_ITER){
					almp_atom_A[signal_Indx] = 0.0;
					almp_atom_F[signal_Indx] = 0.0;
					almp_atom_P[signal_Indx] = 0.0;
				}
				signal_Indx++;
			}
#endif

#if(S_SOURCE)		// Sinal teste

			float32_t A_1 = 0.24363637;		//	1.005 /4.125 = 0.24363637;
			float32_t A_2 = 0.208969697;	//	0.862 /4.125 = 0.208969697;
			float32_t A_3 = 0.174303025;	//	0.719 /4.125 = 0.174303025;
			float32_t A_4 = 0.139636368;	//	0.576 /4.125 = 0.139636368;
			float32_t A_5 = 0.105212122;	//	0.434 /4.125 = 0.105212122;
			float32_t A_6 = 0.0705454573;	//	0.291 /4.125 = 0.0705454573;
			float32_t A_7 = 0.0358787887;	//	0.148 /4.125 = 0.0358787887;
			float32_t A_8 = 0.0218181815;	//	0.090 /4.125 = 0.0218181815;

			float32_t wn_1 = 2.0*(float32_t)M_PI*0.10*60.0*(float32_t)CONS_T_AM; 	// 2*pi *    6 =    37.6991
			float32_t wn_2 = 2.0*(float32_t)M_PI*0.50*60.0*(float32_t)CONS_T_AM; 	// 2*pi *   30 =   188.4956
			float32_t wn_3 = 2.0*(float32_t)M_PI*1.00*60.0*(float32_t)CONS_T_AM; 	// 2*pi *   60 =   376.9911
			float32_t wn_4 = 2.0*(float32_t)M_PI*3.60*60.0*(float32_t)CONS_T_AM; 	// 2*pi *  216 =  1357.6803
			float32_t wn_5 = 2.0*(float32_t)M_PI*7.00*60.0*(float32_t)CONS_T_AM; 	// 2*pi *  420 =  2638.9378
			float32_t wn_6 = 2.0*(float32_t)M_PI*15.4*60.0*(float32_t)CONS_T_AM; 	// 2*pi *  924 =  5805.6632
			float32_t wn_7 = 2.0*(float32_t)M_PI*29.0*60.0*(float32_t)CONS_T_AM; 	// 2*pi * 1740 = 10932.7423
			float32_t wn_8 = 2.0*(float32_t)M_PI*37.8*60.0*(float32_t)CONS_T_AM; 	// 2*pi * 2268 = 14250.2643

			float32_t phi = 2.0*(float32_t)CONS_PI_3;

			for (uint16_t adc_idx = 0; adc_idx < N_MEASUREMENTS; adc_idx++) {
				signal_Residue[signal_Indx] =
						gNoise(0.001, STD_NOISE) +
						//0.80*arm_cos_f32((2.0*M_PI*60*CONS_T_AM)*adc_idx + phi);
						A_1*arm_cos_f32(wn_3*adc_idx + phi) +	// atom = 1;   wn_3 = 376.991;   phi+3 = 5.094 = -1.188
						A_2*arm_cos_f32(wn_1*adc_idx + phi+1) +	// atom = 2;   wn_1 = 37.6991;   phi+1 = 3.094 = -3.188
						A_3*arm_cos_f32(wn_5*adc_idx + phi+5) +	// atom = 3;   wn_5 = 2638.94;   phi+5 = 7.094 = +0.811
						A_4*arm_cos_f32(wn_6*adc_idx + phi+6) +	// atom = 4;   wn_6 = 5805.66;   phi+6 = 8.094 = +1.811
						A_5*arm_cos_f32(wn_4*adc_idx + phi+4) +	// atom = 5;   wn_4 = 1357.68;   phi+4 = 6.094 = -0.188
						A_6*arm_cos_f32(wn_2*adc_idx + phi+2) +	// atom = 6;   wn_2 = 188.496;   phi+2 = 4.094 = -2.188
						A_7*arm_cos_f32(wn_8*adc_idx + phi+8) +	// atom = 7;   wn_8 = 14250.3;   phi+8 = 10.09 = -2.471
						A_8*arm_cos_f32(wn_7*adc_idx + phi+7); 	// atom = 8;   wn_7 = 10932.7;   phi+7 = 9.094 = +2.811

				sum_sq_Input += signal_Residue[signal_Indx] * signal_Residue[signal_Indx];
				signal_Reconst[signal_Indx] = 0.0;
				signal_FFT[signal_Indx] = signal_Residue[signal_Indx];

				if(signal_Indx<=N_ITER){
					almp_atom_A[signal_Indx] = 0.0;
					almp_atom_F[signal_Indx] = 0.0;
					almp_atom_P[signal_Indx] = 0.0;
				}
				signal_Indx++;
			}
#endif

			lm_opts[0]=LM_INIT_MU;
			lm_opts[1]=1E-6;
			lm_opts[2]=1E-6;
			lm_opts[3]=1E-6;
			lm_opts[4]=-LM_DIFF_DELTA;

			// Inicializa FFT
			arm_rfft_fast_instance_f32 RFFT_Handle;
			arm_rfft_fast_init_f32(&RFFT_Handle, N_FFT);

			// Inicio do ALMP
			almp_Iter = 1;
			do{
				// Processa a FFT do vetor signal_FFT
				arm_rfft_fast_f32(&RFFT_Handle, signal_FFT, signal_FFT, 0);

				// Busca a maior magnitude ao quadrado do sinal e seu indice no vetor
				FFT_out_Indx = 0;
				FFT_out_Max = 0.0;
				for (uint16_t FFT_idx=0; FFT_idx<(uint16_t)(N_FFT/2-1); FFT_idx++) {
					FFT_out_Real[FFT_idx] = signal_FFT[FFT_idx*2];
					FFT_out_Imag[FFT_idx] = signal_FFT[(FFT_idx*2)+1];
					FFT_out_Mag = FFT_out_Real[FFT_idx] * FFT_out_Real[FFT_idx] + FFT_out_Imag[FFT_idx] * FFT_out_Imag[FFT_idx];
					if(FFT_out_Max < FFT_out_Mag){
						FFT_out_Max = FFT_out_Mag;
						FFT_out_Indx = FFT_idx;
					}
				}

				// Modulo da maior magnitude do sinal
				arm_sqrt_f32(FFT_out_Max, &FFT_out_Max);

				// Parametros iniciais para o algoritmo de Levenber-Marquardt: Amplitude, Frequencia angular e Fase, respectivamente
				lm_params[0] = 2.0 * FFT_out_Max * (float32_t)N_1_FFT;
				lm_params[1] = 2.0 * (float32_t)M_PI * (float32_t)FFT_out_Indx * (float32_t)CONS_FS_AM * (float32_t)N_1_FFT;
				lm_params[2] = atan2f(FFT_out_Imag[FFT_out_Indx], FFT_out_Real[FFT_out_Indx]);

				// Otimização pelo algoritmo de Levenberg-Marquardt
				//				volatile TickType_t tickStart = xTaskGetTickCount();

				//				slevmar_dif(lm_func_cos_dif, lm_params, signal_Residue, N_PARAMS,
				//						N_MEASUREMENTS, N_ITER, lm_opts, lm_info, lm_work_Buffer, NULL, NULL);
				slevmar_der(lm_func_cos_dif, lm_jacb_cos_der, lm_params, signal_Residue, N_PARAMS,
						N_MEASUREMENTS, N_ITER, lm_opts, lm_info, lm_work_Buffer, NULL, NULL);

				//				volatile TickType_t tickEnd = xTaskGetTickCount();
				//				tickDuring = (uint32_t)(tickEnd - tickStart);
				//
				//				sprintf(buffer, "time (ms): %d\n\r", (int)(tickEnd - tickStart));
				//				UARTPutString(STDOUT, buffer, 0);

				// Guarda os resultados da minimização: Amplitude, Frequencia angular e Fase, respectivamente
				almp_atom_A[almp_Iter] = S_MAGNITUDE*lm_params[0];			// [V]*[pu]
				almp_atom_F[almp_Iter] = lm_params[1] * 0.5 * M_1_PI;		// [rad/s] -> [Hz]
				almp_atom_P[almp_Iter] = lm_params[2] * 180.0 * M_1_PI;		// [rad] -> [grau]
				while(almp_atom_P[almp_Iter] < 0) almp_atom_P[almp_Iter] += 360.0; 		// Transforma fase negativa em positiva

				// Verifica se semaforos do ALMP foram criados
				if (s_ALMP_Graph != NULL && s_ALMP_Text != NULL) {
					// Obtem semaforos e espera ate serem devolvidos
					if (xSemaphoreTake(s_ALMP_Graph, portMAX_DELAY) &&
							xSemaphoreTake(s_ALMP_Text, portMAX_DELAY)) {

						// Atualiza os sinais e energia
						sum_sq_Atom = 0.0;
						sum_sq_Residue = 0.0;
						sum_sq_Reconst = 0.0;
						for(uint16_t almp_Update=0; almp_Update<(uint16_t)N_MEASUREMENTS; almp_Update++){
							signal_Atom[almp_Update] = lm_params[0]*arm_cos_f32(lm_params[1]*(float32_t)CONS_T_AM*almp_Update+lm_params[2]);
							signal_Reconst[almp_Update] += signal_Atom[almp_Update];
							signal_Residue[almp_Update] -= signal_Atom[almp_Update];
							signal_FFT[almp_Update] = signal_Residue[almp_Update];

							sum_sq_Atom += signal_Atom[almp_Update] * signal_Atom[almp_Update];
							sum_sq_Residue += signal_Residue[almp_Update] * signal_Residue[almp_Update];
							sum_sq_Reconst += signal_Reconst[almp_Update] * signal_Reconst[almp_Update];
						}

						// Libera os semaforos para display
						xSemaphoreGive(s_LVGL_Graph);
						xSemaphoreGive(s_LVGL_Text);
					}
				}

				// Compara a energia do residuo a tolerancia definida
				energy_iter_Residue[almp_Iter] = sum_sq_Residue;
				energy_iter_Atom[almp_Iter] = sum_sq_Atom;
				if(energy_iter_Residue[almp_Iter]/sum_sq_Input < (float32_t)I_TOL){
					// Compara o atomo atual com o residuo atual
					if(energy_iter_Atom[almp_Iter] < energy_iter_Residue[almp_Iter]){
						// Zera os paramentos, considerando os valores como ruido
						if(almp_Iter < N_ITER){
							almp_atom_A[almp_Iter+1] = 0.0;
							almp_atom_F[almp_Iter+1] = 0.0;
							almp_atom_P[almp_Iter+1] = 0.0;
						}
						energy_iter_Residue[almp_Iter] = 0.0;
						energy_iter_Atom[almp_Iter] = 0.0;
					}
				}

				// Incremento para proxima iteração do ALMP
				almp_Iter++;

				// Condições de execução do ALMP
			} while(((float32_t)(energy_iter_Residue[almp_Iter-1]/sum_sq_Input) > (float32_t)I_TOL ||
					(float32_t)(energy_iter_Atom[almp_Iter-1]/sum_sq_Input) > (float32_t)I_TOL) &&
					((uint32_t)almp_Iter < (uint32_t)N_ITER));
			sprintf(buffer, "\n\r\n\r");
			UARTPutString(STDOUT, buffer, 0);

			// Alterna os canais do ADC e o layout flex de texto do display
			if (input_Channel==0) input_Channel=1;
			else if (input_Channel==1) input_Channel=2;

			break;
		default:
			break;
		}
		osDelay(1);
	}

	osDelay(1);
}

// Tarefa de tratamento do display com a biblioteca grafica LVGL
void LVGL_Task(void *argument) {
	lv_init();
	tft_init();
	touchpad_init();
	lv_gui();
	while (1) {
		lv_task_handler();
	}
}

// Tarefas de teste com semaforos binarios
void BinarySemaphoreTask01(void *argument) {
	uint16_t val_1_0 = 0;
	UARTInit();
	UARTPutString(STDOUT, "\033[2J\033[H", 0);
	char buffer[256];
	while (1) {
		if (bs1 != NULL) {
			if (xSemaphoreTake(bs1, portMAX_DELAY)) {
				osDelay(1);
				val_1_0++;
				common_variable++;
				sprintf(buffer, "BinarySemaphoreTask01 + bs1:\n\r"
						"\t val_1_0: %d,\t common_variable: %d\n\r",
						(int) (val_1_0), (int) common_variable);
				UARTPutString(STDOUT, buffer, 0);
				xSemaphoreGive(bs3);
			}
		}
	}
}

void BinarySemaphoreTask02(void *argument) {
	uint16_t val_2_0 = 0;
	UARTInit();
	UARTPutString(STDOUT, "\033[2J\033[H", 0);
	char buffer[256];
	while (1) {
		if (bs2 != NULL) {
			if (xSemaphoreTake(bs2, portMAX_DELAY)) {
				osDelay(2);
				val_2_0++;
				common_variable++;
				sprintf(buffer, "BinarySemaphoreTask02 + bs2:\n\r"
						"\t val_2_0: %d,\t common_variable: %d\n\r",
						(int) (val_2_0), (int) common_variable);
				UARTPutString(STDOUT, buffer, 0);
				xSemaphoreGive(bs1);
			}
		}
	}
}

void BinarySemaphoreTask03(void *argument) {
	uint16_t val_3_0 = 0;
	UARTInit();
	UARTPutString(STDOUT, "\033[2J\033[H", 0);
	char buffer[256];
	while (1) {
		if (bs3 != NULL) {
			if (xSemaphoreTake(bs3, portMAX_DELAY)) {
				osDelay(1);
				val_3_0++;
				common_variable++;
				sprintf(buffer, "BinarySemaphoreTask03 + bs3:\n\r"
						"\t val_3_0: %d,\t common_variable: %d\n\r",
						(int) (val_3_0), (int) common_variable);
				UARTPutString(STDOUT, buffer, 0);
				xSemaphoreGive(bs2);
			}
		}
	}
}

/**
 * @brief  Period elapsed callback in non blocking mode
 * @note   This function is called  when TIM1 interrupt took place, inside
 * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
 * a global variable "uwTick" used as application time base.
 * @param  htim : TIM handle
 * @retval None
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	/* USER CODE BEGIN Callback 0 */
	/* USER CODE END Callback 0 */
	if (htim->Instance == TIM1) {
		HAL_IncTick();
	}
	/* USER CODE BEGIN Callback 1 */
	/* USER CODE END Callback 1 */
}

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1)
	{
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
	/* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	/* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
