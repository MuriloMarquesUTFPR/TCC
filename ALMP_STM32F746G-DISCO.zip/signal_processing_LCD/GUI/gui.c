#include "main.h"
#include "FreeRTOS.h"
#include "semphr.h"
#include "serial.h"
#include <stdio.h>
#include "lvgl/lvgl.h"

/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/
typedef enum {
	DISP_SMALL,
	DISP_MEDIUM,
	DISP_LARGE,
}disp_size_t;

/**********************
 *  STATIC PROTOTYPES
 **********************/
static void graph1_create(lv_obj_t * parent);
void graph1_update(lv_timer_t * timer);

static void graph2_create(lv_obj_t * parent);
static void anime_create(lv_obj_t * parent);

static void detalhado_create(lv_obj_t * parent);
void detalhado_timer_cb(lv_timer_t * timer);
void atom_label(int atom, lv_obj_t * label, bool channel);

static void button_create(lv_obj_t * parent);

static void lv_example_chart_3(lv_obj_t * parent);
static void mod(lv_obj_t * parent);
void mod_update(lv_timer_t * timer);
static void mod2(lv_obj_t * parent);

static void draw_event_cb(lv_event_t * e);
static void chart_event_cb(lv_event_t * e);
static void color_changer_anim_cb(void * var, int32_t v);
static void color_changer_create(lv_obj_t * parent);
static void color_changer_event_cb(lv_event_t * e);
static void color_event_cb(lv_event_t * e);

static void meter1_indic1_anim_cb(void * var, int32_t v);
static void meter1_indic2_anim_cb(void * var, int32_t v);
static void meter1_indic3_anim_cb(void * var, int32_t v);

void label_timer(lv_timer_t * timer);
void event_handler(lv_event_t * e);
void event_handler2(lv_event_t * e);

static lv_obj_t * create_meter_box(lv_obj_t * parent, const char * title, const char * text1, const char * text2, const char * text3);

/**********************
 *  STATIC VARIABLES
 **********************/
static disp_size_t disp_size;

static lv_obj_t * tv;
static lv_style_t style_text_muted;
static lv_style_t style_title;
static lv_style_t style_icon;
static lv_style_t style_bullet;

static lv_obj_t * meter1;

static lv_obj_t * chart1;
static lv_obj_t * chart2;
static lv_obj_t * chart3;

static lv_obj_t * detalhado;
static lv_obj_t * flex_1;
static lv_obj_t * flex_2;
static lv_obj_t * label_channel_1;
static lv_obj_t * label_channel_2;

static lv_chart_series_t * ser1;
static lv_chart_series_t * ser2;
static lv_chart_series_t * ser3;
static lv_chart_series_t * ser_m;

static const lv_font_t * font_large;
static const lv_font_t * font_normal;

////////////////////////////////////////////////////////////////

extern uint8_t input_Channel;;
extern uint16_t almp_Iter;
extern float almp_atom_A[], almp_atom_F[], almp_atom_P[];
extern xSemaphoreHandle s_ALMP_Text;
extern xSemaphoreHandle s_LVGL_Text;

extern float signal_Atom[];
extern float signal_Residue[];
extern float signal_Reconst[];
extern xSemaphoreHandle s_ALMP_Graph;
extern xSemaphoreHandle s_LVGL_Graph;
#define N_MEASUREMENT 3072

extern uint16_t ADC_Buffer[2];
////////////////////////////////////////////////////////////////

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

void lv_gui(void){
	disp_size = DISP_MEDIUM;
	font_large = LV_FONT_DEFAULT;
	font_normal = LV_FONT_DEFAULT;
	lv_coord_t tab_h;
	tab_h = 25;

#if LV_FONT_MONTSERRAT_18
	font_large     =  &lv_font_montserrat_18;
#else
	LV_LOG_WARN("LV_FONT_MONTSERRAT_18 is not enabled for the widgets demo. Using LV_FONT_DEFAULT instead.")
#endif
#if LV_FONT_MONTSERRAT_14
	font_normal    =  &lv_font_montserrat_14;
#else
	LV_LOG_WARN("LV_FONT_MONTSERRAT_12 is not enabled for the widgets demo. Using LV_FONT_DEFAULT instead.")
#endif
#if LV_USE_THEME_DEFAULT
	lv_theme_default_init(NULL, lv_palette_main(LV_PALETTE_RED), lv_palette_main(LV_PALETTE_RED), LV_THEME_DEFAULT_DARK, font_normal);
#endif

	//lv_style_set_bg_color(&style_bg, lv_color_hex(0xa76467));
	//lv_style_set_border_width(&style_bg, 16);

	lv_style_init(&style_text_muted);
	lv_style_set_text_opa(&style_text_muted, LV_OPA_50);

	lv_style_init(&style_title);
	lv_style_set_text_font(&style_title, font_large);

	lv_style_init(&style_icon);
	lv_style_set_text_color(&style_icon, lv_theme_get_color_primary(NULL));
	lv_style_set_text_font(&style_icon, font_large);

	lv_style_init(&style_bullet);
	lv_style_set_border_width(&style_bullet, 2);
	lv_style_set_radius(&style_bullet, LV_RADIUS_CIRCLE);

	tv = lv_tabview_create(lv_scr_act(), LV_DIR_TOP, tab_h);
	lv_obj_set_style_text_font(lv_scr_act(), font_normal, 0);

	//	color_changer_create(tv);

	lv_obj_t * d1 = lv_tabview_add_tab(tv, "Detalhado");
	detalhado_create(d1);

	lv_obj_t * t1 = lv_tabview_add_tab(tv, "Tempo");
	graph1_create(t1);

	//	lv_obj_t * ex = lv_tabview_add_tab(tv, "Frequencia");
	//mod2(ex);
	//	mod(ex);
	//lv_example_chart_3(ex);

	//	lv_obj_t * t2 = lv_tabview_add_tab(tv, "Frequencia");
	//	graph2_create(t2);

	//	lv_obj_t * t3 = lv_tabview_add_tab(tv, "Anime/button");
	//	anime_create(t3);

	//		lv_obj_t * t4 = lv_tabview_add_tab(tv, "button");
	//		button_create(t4);

}

/**********************
 *   STATIC FUNCTIONS
 **********************/

/*
 * Color charger begin
 */
static void color_changer_create(lv_obj_t * parent){
	static lv_palette_t palette[] = {
			LV_PALETTE_BLUE, LV_PALETTE_GREEN, LV_PALETTE_BLUE_GREY,  LV_PALETTE_ORANGE,
			LV_PALETTE_RED, LV_PALETTE_PURPLE, LV_PALETTE_TEAL, _LV_PALETTE_LAST };

	lv_obj_t * color_cont = lv_obj_create(parent);
	lv_obj_remove_style_all(color_cont);
	lv_obj_set_flex_flow(color_cont, LV_FLEX_FLOW_ROW);
	lv_obj_set_flex_align(color_cont, LV_FLEX_ALIGN_SPACE_EVENLY, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
	lv_obj_add_flag(color_cont, LV_OBJ_FLAG_FLOATING);

	lv_obj_set_style_bg_color(color_cont, lv_color_white(), 0);
	lv_obj_set_style_pad_right(color_cont, disp_size == DISP_SMALL ? LV_DPX(47) : LV_DPX(55), 0);
	lv_obj_set_style_bg_opa(color_cont, LV_OPA_COVER, 0);
	lv_obj_set_style_radius(color_cont, LV_RADIUS_CIRCLE, 0);

	if(disp_size == DISP_SMALL) lv_obj_set_size(color_cont, LV_DPX(52), LV_DPX(52));
	else lv_obj_set_size(color_cont, LV_DPX(60), LV_DPX(60));

	lv_obj_align(color_cont, LV_ALIGN_BOTTOM_RIGHT, - LV_DPX(10),  - LV_DPX(10));

	uint32_t i;
	for(i = 0; palette[i] != _LV_PALETTE_LAST; i++) {
		lv_obj_t * c = lv_btn_create(color_cont);
		lv_obj_set_style_bg_color(c, lv_palette_main(palette[i]), 0);
		lv_obj_set_style_radius(c, LV_RADIUS_CIRCLE, 0);
		lv_obj_set_style_opa(c, LV_OPA_TRANSP, 0);
		lv_obj_set_size(c, 20, 20);
		lv_obj_add_event_cb(c, color_event_cb, LV_EVENT_ALL, &palette[i]);
		lv_obj_clear_flag(c, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
	}

	lv_obj_t * btn = lv_btn_create(parent);
	lv_obj_add_flag(btn, LV_OBJ_FLAG_FLOATING | LV_OBJ_FLAG_CLICKABLE);
	lv_obj_set_style_bg_color(btn, lv_color_white(), LV_STATE_CHECKED);
	lv_obj_set_style_pad_all(btn, 10, 0);
	lv_obj_set_style_radius(btn, LV_RADIUS_CIRCLE, 0);
	lv_obj_add_event_cb(btn, color_changer_event_cb, LV_EVENT_ALL, color_cont);
	lv_obj_set_style_shadow_width(btn, 0, 0);
	lv_obj_set_style_bg_img_src(btn, LV_SYMBOL_TINT, 0);

	if(disp_size == DISP_SMALL) {
		lv_obj_set_size(btn, LV_DPX(42), LV_DPX(42));
		lv_obj_align(btn, LV_ALIGN_BOTTOM_RIGHT, -LV_DPX(15), -LV_DPX(15));
	} else {
		lv_obj_set_size(btn, LV_DPX(50), LV_DPX(50));
		lv_obj_align(btn, LV_ALIGN_BOTTOM_RIGHT, -LV_DPX(15), -LV_DPX(15));
	}
}

static void color_event_cb(lv_event_t * e) {
	lv_event_code_t code = lv_event_get_code(e);
	lv_obj_t * obj = lv_event_get_target(e);

	if(code == LV_EVENT_FOCUSED) {
		lv_obj_t * color_cont = lv_obj_get_parent(obj);
		if(lv_obj_get_width(color_cont) < LV_HOR_RES / 2) {
			lv_anim_t a;
			lv_anim_init(&a);
			lv_anim_set_var(&a, color_cont);
			lv_anim_set_exec_cb(&a, color_changer_anim_cb);
			lv_anim_set_values(&a, 0, 256);
			lv_anim_set_time(&a, 200);
			lv_anim_start(&a);
		}
	}
	else if(code == LV_EVENT_CLICKED) {
		lv_palette_t * palette_primary = lv_event_get_user_data(e);
		lv_palette_t palette_secondary = (*palette_primary) + 3; /*Use an other palette as secondary*/
		if(palette_secondary >= _LV_PALETTE_LAST) palette_secondary = 0;

		lv_theme_default_init(NULL, lv_palette_main(*palette_primary), lv_palette_main(palette_secondary), LV_THEME_DEFAULT_DARK, font_normal);

		lv_color_t color = lv_palette_main(*palette_primary);
		lv_style_set_text_color(&style_icon, color);
		lv_chart_set_series_color(chart1, ser1, color);
		lv_chart_set_series_color(chart2, ser3, color);
	}
}

static void color_changer_event_cb(lv_event_t *e){
	if(lv_event_get_code(e) == LV_EVENT_CLICKED) {
		lv_obj_t * color_cont = lv_event_get_user_data(e);
		if(lv_obj_get_width(color_cont) < LV_HOR_RES / 2) {
			lv_anim_t a;
			lv_anim_init(&a);
			lv_anim_set_var(&a, color_cont);
			lv_anim_set_exec_cb(&a, color_changer_anim_cb);
			lv_anim_set_values(&a, 0, 256);
			lv_anim_set_time(&a, 200);
			lv_anim_start(&a);
		} else {
			lv_anim_t a;
			lv_anim_init(&a);
			lv_anim_set_var(&a, color_cont);
			lv_anim_set_exec_cb(&a, color_changer_anim_cb);
			lv_anim_set_values(&a, 256, 0);
			lv_anim_set_time(&a, 200);
			lv_anim_start(&a);
		}
	}
}

static void color_changer_anim_cb(void * var, int32_t v){
	lv_obj_t * obj = var;
	lv_coord_t max_w = lv_obj_get_width(lv_obj_get_parent(obj)) - LV_DPX(20);
	lv_coord_t w;

	if(disp_size == DISP_SMALL) {
		w = lv_map(v, 0, 256, LV_DPX(52), max_w);
		lv_obj_set_width(obj, w);
		lv_obj_align(obj, LV_ALIGN_BOTTOM_RIGHT, - LV_DPX(10),  - LV_DPX(10));
	} else {
		w = lv_map(v, 0, 256, LV_DPX(60), max_w);
		lv_obj_set_width(obj, w);
		lv_obj_align(obj, LV_ALIGN_BOTTOM_RIGHT, - LV_DPX(10),  - LV_DPX(10));
	}

	if(v > LV_OPA_COVER) v = LV_OPA_COVER;

	uint32_t i;
	for(i = 0; i < lv_obj_get_child_cnt(obj); i++) {
		lv_obj_set_style_opa(lv_obj_get_child(obj, i), v, 0);
	}

}
/*
 * Color charger end
 */

/*
 * Graph1 tab begin
 */
static void graph1_create(lv_obj_t * parent){
	lv_obj_set_flex_flow(parent, LV_FLEX_FLOW_ROW_WRAP);

	static lv_coord_t grid_chart_row_dsc[] = {LV_GRID_CONTENT, LV_GRID_FR(1), 10, LV_GRID_TEMPLATE_LAST};
	static lv_coord_t grid_chart_col_dsc[] = {20, LV_GRID_FR(1), LV_GRID_TEMPLATE_LAST};

	lv_obj_t * chart1_cont = lv_obj_create(parent);
	lv_obj_set_flex_grow(chart1_cont, 1);
	lv_obj_set_grid_dsc_array(chart1_cont, grid_chart_col_dsc, grid_chart_row_dsc);

	lv_obj_set_height(chart1_cont, LV_PCT(100));
	lv_obj_set_style_max_height(chart1_cont, 300, 0);

	lv_obj_t * title = lv_label_create(chart1_cont);
	lv_label_set_text(title, "Forma de onda:");
	lv_obj_add_style(title, &style_text_muted, 0);
	lv_obj_set_grid_cell(title, LV_GRID_ALIGN_START, 0, 2, LV_GRID_ALIGN_START, 0, 1);

	chart1 = lv_chart_create(chart1_cont);
	lv_group_add_obj(lv_group_get_default(), chart1);
	lv_obj_add_flag(chart1, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
	lv_obj_set_grid_cell(chart1, LV_GRID_ALIGN_STRETCH, 1, 1, LV_GRID_ALIGN_STRETCH, 1, 1);
	lv_chart_set_axis_tick(chart1, LV_CHART_AXIS_PRIMARY_Y, 4, 2, 7, 2, true, 200);
	lv_chart_set_axis_tick(chart1, LV_CHART_AXIS_PRIMARY_X, 4, 2, 12, 2, true , 200);
	lv_chart_set_div_line_count(chart1, 7, 13);
	lv_chart_set_point_count(chart1, N_MEASUREMENT);
	lv_chart_set_range(chart1, LV_CHART_AXIS_PRIMARY_Y, -120, 120);
	lv_obj_add_event_cb(chart1, chart_event_cb, LV_EVENT_ALL, NULL);
	//	if(disp_size == DISP_SMALL) lv_chart_set_zoom_x(chart1, 256 * 3);
	//	else if(disp_size == DISP_MEDIUM) lv_chart_set_aoom_x(chart1, 256 * 2);

	lv_obj_set_style_border_side(chart1, LV_BORDER_SIDE_LEFT | LV_BORDER_SIDE_BOTTOM, 0);
	lv_obj_set_style_radius(chart1, 0, 0);

	//	lv_chart_set_update_mode(chart1, LV_CHART_UPDATE_MODE_CIRCULAR);
	ser1 = lv_chart_add_series(chart1, lv_theme_get_color_primary(chart1), LV_CHART_AXIS_PRIMARY_Y);

	lv_timer_t * graph1_timer = lv_timer_create(graph1_update, 500,  NULL);
	(void)graph1_timer;
	lv_chart_refresh(chart1);
}

static void chart_event_cb(lv_event_t * e) {
	lv_event_code_t code = lv_event_get_code(e);
	lv_obj_t * obj = lv_event_get_target(e);

	if(code == LV_EVENT_PRESSED || code == LV_EVENT_RELEASED) {
		lv_obj_invalidate(obj); /*To make the value boxes visible*/
	}
	else if(code == LV_EVENT_DRAW_PART_BEGIN) {
		lv_obj_draw_part_dsc_t * dsc = lv_event_get_param(e);
		/*Set the markers' text*/
		if(dsc->part == LV_PART_TICKS && dsc->id == LV_CHART_AXIS_PRIMARY_X) {
			if(lv_chart_get_type(obj) == LV_CHART_TYPE_BAR) {
				const char * month[] = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"};
				lv_snprintf(dsc->text, sizeof(dsc->text), "%s", month[dsc->value]);
			} else {
				//const char * month[] = {"Jan", "Febr", "March", "Apr", "May", "Jun", "July", "Aug", "Sept", "Oct", "Nov", "Dec"};
				//lv_snprintf(dsc->text, sizeof(dsc->text), "%s", month[dsc->value]);
			}
		}

		/*Add the faded area before the lines are drawn */
		else if(dsc->part == LV_PART_ITEMS) {
#if LV_DRAW_COMPLEX
			/*Add  a line mask that keeps the area below the line*/
			if(dsc->p1 && dsc->p2) {
				lv_draw_mask_line_param_t line_mask_param;
				lv_draw_mask_line_points_init(&line_mask_param, dsc->p1->x, dsc->p1->y, dsc->p2->x, dsc->p2->y, LV_DRAW_MASK_LINE_SIDE_BOTTOM);
				int16_t line_mask_id = lv_draw_mask_add(&line_mask_param, NULL);

				/*Add a fade effect: transparent bottom covering top*/
				lv_coord_t h = lv_obj_get_height(obj);
				lv_draw_mask_fade_param_t fade_mask_param;
				lv_draw_mask_fade_init(&fade_mask_param, &obj->coords, LV_OPA_COVER, obj->coords.y1 + h / 8, LV_OPA_TRANSP, obj->coords.y2);
				int16_t fade_mask_id = lv_draw_mask_add(&fade_mask_param, NULL);

				/*Draw a rectangle that will be affected by the mask*/
				lv_draw_rect_dsc_t draw_rect_dsc;
				lv_draw_rect_dsc_init(&draw_rect_dsc);
				draw_rect_dsc.bg_opa = LV_OPA_50;
				draw_rect_dsc.bg_color = dsc->line_dsc->color;

				lv_area_t obj_clip_area;
				_lv_area_intersect(&obj_clip_area, dsc->clip_area, &obj->coords);

				lv_area_t a;
				a.x1 = dsc->p1->x;
				a.x2 = dsc->p2->x - 1;
				a.y1 = LV_MIN(dsc->p1->y, dsc->p2->y);
				a.y2 = obj->coords.y2;
				lv_draw_rect(&a, &obj_clip_area, &draw_rect_dsc);

				/*Remove the masks*/
				lv_draw_mask_remove_id(line_mask_id);
				lv_draw_mask_remove_id(fade_mask_id);
			}
#endif
			const lv_chart_series_t * ser = dsc->sub_part_ptr;

			if(lv_chart_get_pressed_point(obj) == dsc->id) {
				if(lv_chart_get_type(obj) == LV_CHART_TYPE_LINE) {
					dsc->rect_dsc->outline_color = lv_color_white();
					dsc->rect_dsc->outline_width = 2;
				} else {
					dsc->rect_dsc->shadow_color = ser->color;
					dsc->rect_dsc->shadow_width = 15;
					dsc->rect_dsc->shadow_spread = 0;
				}

				char buf[8];
				lv_snprintf(buf, sizeof(buf), "%d", dsc->value);

				lv_point_t text_size;
				lv_txt_get_size(&text_size, buf, font_normal, 0, 0, LV_COORD_MAX, LV_TEXT_FLAG_NONE);

				lv_area_t txt_area;
				if(lv_chart_get_type(obj) == LV_CHART_TYPE_BAR) {
					txt_area.y2 = dsc->draw_area->y1 - LV_DPX(15);
					txt_area.y1 = txt_area.y2 - text_size.y;
					if(ser == lv_chart_get_series_next(obj, NULL)) {
						txt_area.x1 = dsc->draw_area->x1 + lv_area_get_width(dsc->draw_area) / 2;
						txt_area.x2 = txt_area.x1 + text_size.x;
					} else {
						txt_area.x2 = dsc->draw_area->x1 + lv_area_get_width(dsc->draw_area) / 2;
						txt_area.x1 = txt_area.x2 - text_size.x;
					}
				} else {
					txt_area.x1 = dsc->draw_area->x1 + lv_area_get_width(dsc->draw_area) / 2 - text_size.x / 2;
					txt_area.x2 = txt_area.x1 + text_size.x;
					txt_area.y2 = dsc->draw_area->y1 - LV_DPX(15);
					txt_area.y1 = txt_area.y2 - text_size.y;
				}

				lv_area_t bg_area;
				bg_area.x1 = txt_area.x1 - LV_DPX(8);
				bg_area.x2 = txt_area.x2 + LV_DPX(8);
				bg_area.y1 = txt_area.y1 - LV_DPX(8);
				bg_area.y2 = txt_area.y2 + LV_DPX(8);

				lv_draw_rect_dsc_t rect_dsc;
				lv_draw_rect_dsc_init(&rect_dsc);
				rect_dsc.bg_color = ser->color;
				rect_dsc.radius = LV_DPX(5);
				lv_draw_rect(&bg_area, dsc->clip_area, &rect_dsc);

				lv_draw_label_dsc_t label_dsc;
				lv_draw_label_dsc_init(&label_dsc);
				label_dsc.color = lv_color_white();
				label_dsc.font = font_normal;
				lv_draw_label(&txt_area, dsc->clip_area, &label_dsc, buf, NULL);
			} else {
				dsc->rect_dsc->outline_width = 0;
				dsc->rect_dsc->shadow_width = 0;
			}
		}
	}
}

void graph1_update(lv_timer_t * timer_graph){
	if (s_LVGL_Graph != NULL) {
		if (xSemaphoreTake(s_LVGL_Graph, 0)) {
			if(almp_Iter == 1 && input_Channel < 2){
				for (int i=0;i<(int)(N_MEASUREMENT);i++){
					lv_chart_set_next_value(chart1, ser1, (lv_coord_t)(signal_Residue[i]*100));
				}
			}
			xSemaphoreGive(s_ALMP_Graph);
		}
	}
}
/*
 * Graph1 tab end
 */

/*
 * Graph2 tab end
 */
static void graph2_create(lv_obj_t * parent)
{
	lv_obj_set_flex_flow(parent, LV_FLEX_FLOW_ROW_WRAP);

	static lv_coord_t grid_chart_row_dsc[] = {LV_GRID_CONTENT, LV_GRID_FR(1), 10, LV_GRID_TEMPLATE_LAST};
	static lv_coord_t grid_chart_col_dsc[] = {20, LV_GRID_FR(1), LV_GRID_TEMPLATE_LAST};

	lv_obj_t * chart2_cont = lv_obj_create(parent);
	//lv_obj_add_flag(chart2_cont, LV_OBJ_FLAG_FLEX_IN_NEW_TRACK);
	lv_obj_set_flex_grow(chart2_cont, 1);

	lv_obj_set_height(chart2_cont, LV_PCT(100));
	lv_obj_set_style_max_height(chart2_cont, 300, 0);

	lv_obj_set_grid_dsc_array(chart2_cont, grid_chart_col_dsc, grid_chart_row_dsc);

	lv_obj_t * title = lv_label_create(chart2_cont);
	lv_label_set_text(title, "Composicao do sinal");
	lv_obj_add_style(title, &style_text_muted, 0);
	lv_obj_set_grid_cell(title, LV_GRID_ALIGN_START, 0, 2, LV_GRID_ALIGN_START, 0, 1);

	chart2 = lv_chart_create(chart2_cont);
	lv_group_add_obj(lv_group_get_default(), chart2);
	lv_obj_add_flag(chart2, LV_OBJ_FLAG_SCROLL_ON_FOCUS);

	lv_obj_set_grid_cell(chart2, LV_GRID_ALIGN_STRETCH, 1, 1, LV_GRID_ALIGN_STRETCH, 1, 1);
	lv_chart_set_axis_tick(chart2, LV_CHART_AXIS_PRIMARY_Y, 0, 0, 5, 1, true, 80);
	lv_chart_set_axis_tick(chart2, LV_CHART_AXIS_PRIMARY_X, 0, 0, 12, 1, true, 50);
	lv_obj_set_size(chart2, LV_PCT(100), LV_PCT(100));
	lv_chart_set_type(chart2, LV_CHART_TYPE_LINE);
	lv_chart_set_div_line_count(chart2, 6, 0);
	lv_chart_set_point_count(chart2, 12);
	lv_obj_add_event_cb(chart2, chart_event_cb, LV_EVENT_ALL, NULL);
	lv_chart_set_zoom_x(chart2, 256 * 2);
	lv_obj_set_style_border_side(chart2, LV_BORDER_SIDE_LEFT | LV_BORDER_SIDE_BOTTOM, 0);
	lv_obj_set_style_radius(chart2, 0, 0);

	if(disp_size == DISP_SMALL) {
		lv_obj_set_style_pad_gap(chart2, 0, LV_PART_ITEMS);
		lv_obj_set_style_pad_gap(chart2, 2, LV_PART_MAIN);
	}
	else if(disp_size == DISP_LARGE) {
		lv_obj_set_style_pad_gap(chart2, 16, 0);
	}

	ser2 = lv_chart_add_series(chart2, lv_palette_lighten(LV_PALETTE_GREY, 1), LV_CHART_AXIS_PRIMARY_Y);
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser2, lv_rand(10, 80));

	ser3 = lv_chart_add_series(chart2, lv_theme_get_color_primary(chart1), LV_CHART_AXIS_PRIMARY_Y);
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
	lv_chart_set_next_value(chart2, ser3, lv_rand(10, 80));
}
/*
 * Graph2 tab end
 */

/*
 * Anime tab begin
 */
void anime_create(lv_obj_t * parent) {
	lv_obj_set_flex_flow(parent, LV_FLEX_FLOW_ROW_WRAP);

	lv_meter_scale_t * scale;
	lv_meter_indicator_t *indic;
	meter1 = create_meter_box(parent, "Monthly Target", "Revenue: 63%", "Sales: 44%", "Costs: 58%");
	lv_obj_add_flag(lv_obj_get_parent(meter1), LV_OBJ_FLAG_FLEX_IN_NEW_TRACK);
	scale = lv_meter_add_scale(meter1);
	lv_meter_set_scale_range(meter1, scale, 0, 100, 270, 90);
	lv_meter_set_scale_ticks(meter1, scale, 0, 0, 0, lv_color_black());

	lv_anim_t a;
	lv_anim_init(&a);
	lv_anim_set_values(&a, 20, 100);
	lv_anim_set_repeat_count(&a, LV_ANIM_REPEAT_INFINITE);

	indic = lv_meter_add_arc(meter1, scale, 15, lv_palette_main(LV_PALETTE_BLUE), 0);
	lv_anim_set_exec_cb(&a, meter1_indic1_anim_cb);
	lv_anim_set_var(&a, indic);
	lv_anim_set_time(&a, 4100);
	lv_anim_set_playback_time(&a, 2700);
	lv_anim_start(&a);

	indic = lv_meter_add_arc(meter1, scale, 15, lv_palette_main(LV_PALETTE_RED), -20);
	lv_anim_set_exec_cb(&a, meter1_indic2_anim_cb);
	lv_anim_set_var(&a, indic);
	lv_anim_set_time(&a, 2600);
	lv_anim_set_playback_time(&a, 3200);
	a.user_data = indic;
	lv_anim_start(&a);

	indic = lv_meter_add_arc(meter1, scale, 15, lv_palette_main(LV_PALETTE_GREEN), -40);
	lv_anim_set_exec_cb(&a, meter1_indic3_anim_cb);
	lv_anim_set_var(&a, indic);
	lv_anim_set_time(&a, 2800);
	lv_anim_set_playback_time(&a, 1800);
	lv_anim_start(&a);

	lv_obj_update_layout(parent);
	if(disp_size == DISP_MEDIUM) {
		lv_obj_set_size(meter1, 140, 140);
	} else {
		lv_coord_t meter_w = lv_obj_get_width(meter1);
		lv_obj_set_height(meter1, meter_w);
	}
}

static lv_obj_t * create_meter_box(lv_obj_t * parent, const char * title, const char * text1, const char * text2, const char * text3) {
	lv_obj_t * cont = lv_obj_create(parent);
	lv_obj_set_height(cont, LV_SIZE_CONTENT);
	lv_obj_set_flex_grow(cont, 1);

	lv_obj_t * title_label = lv_label_create(cont);
	lv_label_set_text(title_label, title);
	lv_obj_add_style(title_label, &style_title, 0);

	lv_obj_t * meter = lv_meter_create(cont);
	lv_obj_remove_style(meter, NULL, LV_PART_MAIN);
	lv_obj_remove_style(meter, NULL, LV_PART_INDICATOR);
	lv_obj_set_width(meter, LV_PCT(100));

	lv_obj_t * bullet1 = lv_obj_create(cont);
	lv_obj_set_size(bullet1, 13, 13);
	lv_obj_remove_style(bullet1, NULL, LV_PART_SCROLLBAR);
	lv_obj_add_style(bullet1, &style_bullet, 0);
	lv_obj_set_style_bg_color(bullet1, lv_palette_main(LV_PALETTE_RED), 0);
	lv_obj_t * label1 = lv_label_create(cont);
	lv_label_set_text(label1, text1);

	lv_obj_t * bullet2 = lv_obj_create(cont);
	lv_obj_set_size(bullet2, 13, 13);
	lv_obj_remove_style(bullet2, NULL, LV_PART_SCROLLBAR);
	lv_obj_add_style(bullet2, &style_bullet, 0);
	lv_obj_set_style_bg_color(bullet2, lv_palette_main(LV_PALETTE_BLUE), 0);
	lv_obj_t * label2 = lv_label_create(cont);
	lv_label_set_text(label2, text2);

	lv_obj_t * bullet3 = lv_obj_create(cont);
	lv_obj_set_size(bullet3, 13, 13);
	lv_obj_remove_style(bullet3,  NULL, LV_PART_SCROLLBAR);
	lv_obj_add_style(bullet3, &style_bullet, 0);
	lv_obj_set_style_bg_color(bullet3, lv_palette_main(LV_PALETTE_GREEN), 0);
	lv_obj_t * label3 = lv_label_create(cont);
	lv_label_set_text(label3, text3);

	if(disp_size == DISP_MEDIUM) {
		static lv_coord_t grid_col_dsc[] = {LV_GRID_CONTENT, LV_GRID_FR(1), LV_GRID_CONTENT,LV_GRID_FR(8), LV_GRID_TEMPLATE_LAST};
		static lv_coord_t grid_row_dsc[] = {LV_GRID_CONTENT, LV_GRID_FR(1), LV_GRID_CONTENT, LV_GRID_CONTENT, LV_GRID_CONTENT, LV_GRID_FR(1), LV_GRID_TEMPLATE_LAST};

		lv_obj_set_grid_dsc_array(cont, grid_col_dsc, grid_row_dsc);
		lv_obj_set_grid_cell(title_label, LV_GRID_ALIGN_START, 0, 4, LV_GRID_ALIGN_START, 0, 1);
		lv_obj_set_grid_cell(meter, LV_GRID_ALIGN_START, 0, 1, LV_GRID_ALIGN_START, 1, 3);
		lv_obj_set_grid_cell(bullet1, LV_GRID_ALIGN_START, 2, 1, LV_GRID_ALIGN_CENTER, 2, 1);
		lv_obj_set_grid_cell(bullet2, LV_GRID_ALIGN_START, 2, 1, LV_GRID_ALIGN_CENTER, 3, 1);
		lv_obj_set_grid_cell(bullet3, LV_GRID_ALIGN_START, 2, 1, LV_GRID_ALIGN_CENTER, 4, 1);
		lv_obj_set_grid_cell(label1, LV_GRID_ALIGN_STRETCH, 3, 1, LV_GRID_ALIGN_CENTER, 2, 1);
		lv_obj_set_grid_cell(label2, LV_GRID_ALIGN_STRETCH, 3, 1, LV_GRID_ALIGN_CENTER, 3, 1);
		lv_obj_set_grid_cell(label3, LV_GRID_ALIGN_STRETCH, 3, 1, LV_GRID_ALIGN_CENTER, 4, 1);
	}
	else {
		static lv_coord_t grid_col_dsc[] = {LV_GRID_CONTENT, LV_GRID_FR(1), LV_GRID_TEMPLATE_LAST};
		static lv_coord_t grid_row_dsc[] = {LV_GRID_CONTENT, LV_GRID_CONTENT, LV_GRID_CONTENT, LV_GRID_CONTENT, LV_GRID_CONTENT, LV_GRID_TEMPLATE_LAST};
		lv_obj_set_grid_dsc_array(cont, grid_col_dsc, grid_row_dsc);
		lv_obj_set_grid_cell(title_label, LV_GRID_ALIGN_START, 0, 2, LV_GRID_ALIGN_START, 0, 1);
		lv_obj_set_grid_cell(meter, LV_GRID_ALIGN_START, 0, 2, LV_GRID_ALIGN_START, 1, 1);
		lv_obj_set_grid_cell(bullet1, LV_GRID_ALIGN_START, 0, 1, LV_GRID_ALIGN_START, 2, 1);
		lv_obj_set_grid_cell(bullet2, LV_GRID_ALIGN_START, 0, 1, LV_GRID_ALIGN_START, 3, 1);
		lv_obj_set_grid_cell(bullet3, LV_GRID_ALIGN_START, 0, 1, LV_GRID_ALIGN_START, 4, 1);
		lv_obj_set_grid_cell(label1, LV_GRID_ALIGN_STRETCH, 1, 1, LV_GRID_ALIGN_START, 2, 1);
		lv_obj_set_grid_cell(label2, LV_GRID_ALIGN_STRETCH, 1, 1, LV_GRID_ALIGN_START, 3, 1);
		lv_obj_set_grid_cell(label3, LV_GRID_ALIGN_STRETCH, 1, 1, LV_GRID_ALIGN_START, 4, 1);
	}
	return meter;
}

static void meter1_indic1_anim_cb(void * var, int32_t v){
	lv_meter_set_indicator_end_value(meter1, var, v);
	lv_obj_t * card = lv_obj_get_parent(meter1);
	lv_obj_t * label = lv_obj_get_child(card, -5);
	lv_label_set_text_fmt(label, "Revenue: %d %%", v);
}

static void meter1_indic2_anim_cb(void * var, int32_t v){
	lv_meter_set_indicator_end_value(meter1, var, v);
	lv_obj_t * card = lv_obj_get_parent(meter1);
	lv_obj_t * label = lv_obj_get_child(card, -3);
	lv_label_set_text_fmt(label, "Sales: %d %%", v);
}

static void meter1_indic3_anim_cb(void * var, int32_t v){
	lv_meter_set_indicator_end_value(meter1, var, v);
	lv_obj_t * card = lv_obj_get_parent(meter1);
	lv_obj_t * label = lv_obj_get_child(card, -1);
	lv_label_set_text_fmt(label, "Costs: %d %%", v);
}
/*
 * Anime tab end
 */

/*
 *  Button tab begin
 */
uint32_t timer_init = 0;
lv_obj_t * ta;
static void button_create(lv_obj_t * parent) {
	// Limpa a tela do terminal
#if 0
	/*Configure GPIO pin Output Level */
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	__HAL_RCC_GPIOI_CLK_ENABLE();
	HAL_GPIO_WritePin(GPIOI, GPIO_PIN_1, GPIO_PIN_RESET);

	/*Configure GPIO pins : PD12 PD13 PD14 PD15 */
	GPIO_InitStruct.Pin = GPIO_PIN_1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOI, &GPIO_InitStruct);
#endif

	lv_obj_t * label;

	lv_obj_t * btn1 = lv_btn_create(parent);
	lv_obj_add_event_cb(btn1, event_handler, LV_EVENT_ALL, NULL);
	lv_obj_align(btn1, LV_ALIGN_CENTER, 0, -20);

	label = lv_label_create(btn1);
	lv_label_set_text(label, "Button");
	lv_obj_center(label);

	lv_obj_t * btn2 = lv_btn_create(parent);
	lv_obj_add_event_cb(btn2, event_handler2, LV_EVENT_ALL, NULL);
	lv_obj_align(btn2, LV_ALIGN_CENTER, 0, 40);
	lv_obj_add_flag(btn2, LV_OBJ_FLAG_CHECKABLE);
	lv_obj_set_height(btn2, LV_SIZE_CONTENT);

	label = lv_label_create(btn2);
	lv_label_set_text(label, "Toggle");
	lv_obj_center(label);

	ta = lv_textarea_create(parent);
	lv_textarea_set_one_line(ta, true);
	lv_obj_align(ta, LV_ALIGN_TOP_MID, 0, 10);

	lv_timer_t * timer = lv_timer_create(label_timer, 2000,  NULL);
	(void)timer;
	//	lv_timer_set_period(timer, 200);
}

void event_handler(lv_event_t * e) {
	lv_event_code_t code = lv_event_get_code(e);
	if(code == LV_EVENT_CLICKED) {
		UARTPutString(STDOUT, "Botão pressionado\n\r",20);
		//HAL_GPIO_TogglePin(GPIOI, GPIO_PIN_1);
	}
}

void event_handler2(lv_event_t * e) {
	lv_event_code_t code = lv_event_get_code(e);
	if(code == LV_EVENT_CLICKED) {
		LV_LOG_USER("Clicked");
	}
	else if(code == LV_EVENT_VALUE_CHANGED) {
		LV_LOG_USER("Toggled");
	}
}

extern uint16_t tickDuring;
void label_timer(lv_timer_t * timer) {
	char buffer[32];
	sprintf(buffer, "Valor do ADC: %lu", tickDuring);
	lv_textarea_set_text(ta, buffer);
	if (!timer_init){
		timer_init = 1;
		lv_timer_set_period(timer, 200);
	}
}
/*
 * Button tab end
 */

/*
 * Exemplo tab begin
 */
static void lv_example_chart_3(lv_obj_t * parent)
{
	/*Create a chart*/
	lv_obj_t * chart;
	chart = lv_chart_create(parent);
	lv_obj_set_size(chart, (480-32), (272-32-30));
	lv_obj_center(chart);
	lv_chart_set_type(chart, LV_CHART_TYPE_BAR);
	//    lv_chart_set_range(chart, LV_CHART_AXIS_PRIMARY_Y, 0, 50);
	//    lv_chart_set_range(chart, LV_CHART_AXIS_SECONDARY_Y, 0, 400);

	int x=39;
	lv_chart_set_point_count(chart, x);

	//    lv_obj_add_event_cb(chart, draw_event_cb, LV_EVENT_DRAW_PART_BEGIN, NULL);

	/*Add ticks and label to every axis*/
	//    lv_chart_set_axis_tick(chart, LV_CHART_AXIS_PRIMARY_X, 10, 5, 12, 3, true, 40);
	//    lv_chart_set_axis_tick(chart, LV_CHART_AXIS_PRIMARY_Y, 10, 5, 6, 2, true, 50);
	//    lv_chart_set_axis_tick(chart, LV_CHART_AXIS_SECONDARY_Y, 10, 5, 3, 4, true, 50);

	/*Zoom in a little in X*/
	//    lv_chart_set_zoom_x(chart, 800);

	/*Add two data series*/
	lv_chart_series_t * ser1 = lv_chart_add_series(chart, lv_palette_lighten(LV_PALETTE_GREEN, 2), LV_CHART_AXIS_PRIMARY_Y);
	//    lv_chart_series_t * ser2 = lv_chart_add_series(chart, lv_palette_darken(LV_PALETTE_GREEN, 2), LV_CHART_AXIS_SECONDARY_Y);

	/*Set the next points on 'ser1'*/
	int y=0;
	for(y=0; y<(x+1); y++){
		lv_chart_set_next_value(chart, ser1, y);
	}
}

static void draw_event_cb(lv_event_t * e)
{
	lv_obj_draw_part_dsc_t * dsc = lv_event_get_draw_part_dsc(e);
	//    if(!lv_obj_draw_part_check_type(dsc, &lv_chart_class, LV_CHART_DRAW_PART_TICK_LABEL)) return;

	if(dsc->id == LV_CHART_AXIS_PRIMARY_X && dsc->text) {
		const char * month[] = {"Jan", "Febr", "March", "Apr", "May", "Jun", "July", "Aug", "Sept", "Oct", "Nov", "Dec"};
		//        lv_snprintf(dsc->text, dsc->text_length, "%s", month[dsc->value]);
	}
}

static void mod(lv_obj_t * parent)
{
	int x=34;

	/*Create a chart*/
	chart3 = lv_chart_create(parent);
	lv_obj_set_size(chart3, 400, 200);

	lv_obj_align(chart3, LV_ALIGN_CENTER, 10, -5);

	lv_chart_set_type(chart3, LV_CHART_TYPE_BAR);
	//lv_obj_set_style_line_width(chart3, 20, LV_PART_ITEMS);
	lv_chart_set_range(chart3, LV_CHART_AXIS_PRIMARY_X, 0, 100);
	lv_chart_set_range(chart3, LV_CHART_AXIS_PRIMARY_Y, 0, 100);

	lv_chart_set_point_count(chart3, x);

	//lv_obj_add_event_cb(chart, draw_event_cb,
	//LV_EVENT_DRAW_PART_BEGIN, NULL);

	/*Add ticks and label to every axis*/
	lv_chart_set_axis_tick(chart3, LV_CHART_AXIS_PRIMARY_X,
			10, 5,
			11, 2, //(lv_coord_t)(((float)x)*0.1), 2,
			true, 100);
	lv_chart_set_axis_tick(chart3, LV_CHART_AXIS_PRIMARY_Y,
			10, 5,
			6, 2,
			true, 100);
	lv_chart_set_div_line_count(chart3, 6, 11);

	/*Zoom in a little in X*/
	lv_chart_set_zoom_x(chart3, 256*1);

	lv_chart_set_update_mode(chart1, LV_CHART_UPDATE_MODE_SHIFT);

	/*Add two data series*/
	lv_chart_series_t * ser_m = lv_chart_add_series(chart3,
			lv_palette_lighten(LV_PALETTE_GREEN, 2),
			LV_CHART_AXIS_PRIMARY_X);
	//    lv_chart_series_t * ser2 = lv_chart_add_series(chart,
	//    		lv_palette_darken(LV_PALETTE_GREEN, 2),
	//			LV_CHART_AXIS_SECONDARY_Y);

	//	lv_timer_t * mod_timer = lv_timer_create(mod_update, 500,  NULL);
	//	(void)mod_timer;

	for(int id=0; id<x-20; id++){
		lv_chart_set_value_by_id(chart3, ser_m, (lv_coord_t)lv_rand(1, 33), (lv_coord_t)lv_rand(1, 99));
	}

	//lv_chart_set_next_value(chart3, ser_m, (lv_coord_t)lv_rand(1, 399));

}

void mod_update(lv_timer_t * timer_graph){
	/*Set the next points on 'ser1'*/
	//    for(int i=0; i<5; i++){
	//	lv_chart_set_value_by_id(chart3, ser_m, (lv_coord_t)1, (lv_coord_t)lv_rand(1, 399));
	//	lv_chart_set_next_value(chart3, ser_m, (lv_coord_t)lv_rand(1, 399));
	//    	lv_chart_refresh(chart3);
	//    }
}

static void mod2(lv_obj_t * parent){
}
/*
 * Exemplo tab end
 */

/*
 * Detalhado tab begin
 */
static void detalhado_create(lv_obj_t * parent) {

	detalhado = lv_obj_create(parent);
	lv_obj_set_size(detalhado, (480-32), (272-32-30));
	lv_obj_center(detalhado);
	lv_obj_set_flex_flow(detalhado, LV_FLEX_FLOW_ROW_WRAP);

	flex_1 = lv_obj_create(detalhado);
	lv_obj_set_size(flex_1, 200, LV_SIZE_CONTENT);
	label_channel_1 = lv_label_create(flex_1);
	lv_label_set_text_fmt(label_channel_1, "\tCanal 1");

	flex_2 = lv_obj_create(detalhado);
	lv_obj_set_size(flex_2, 200, LV_SIZE_CONTENT);
	label_channel_2 = lv_label_create(flex_2);
	lv_label_set_text_fmt(label_channel_2, "\tCanal 2");

	lv_timer_t * detalhado_timer = lv_timer_create(detalhado_timer_cb, 500,  NULL);
	(void)detalhado_timer;
}

void detalhado_timer_cb(lv_timer_t * timer_graph) {
	if (s_LVGL_Text != NULL) {
		if (xSemaphoreTake(s_LVGL_Text, 0)) {
			if(input_Channel == 0){
				atom_label(almp_Iter, label_channel_1, input_Channel);
				lv_obj_center(label_channel_1);
			}
			else if(input_Channel == 1){
				atom_label(almp_Iter, label_channel_2, input_Channel);
				lv_obj_center(label_channel_2);
			}
			xSemaphoreGive(s_ALMP_Text);
		}
	}
}

void atom_label(int atom, lv_obj_t * label, bool channel) {
	if(atom==1){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1]);
	}
	else if(atom==2){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 2: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1],
				almp_atom_A[2], almp_atom_F[2], almp_atom_P[2]);
	}
	else if(atom==3){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 2: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 3: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1],
				almp_atom_A[2], almp_atom_F[2], almp_atom_P[2],
				almp_atom_A[3], almp_atom_F[3], almp_atom_P[3]);
	}
	else if(atom==4){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 2: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 3: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 4: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1],
				almp_atom_A[2], almp_atom_F[2], almp_atom_P[2],
				almp_atom_A[3], almp_atom_F[3], almp_atom_P[3],
				almp_atom_A[4], almp_atom_F[4], almp_atom_P[4]);
	}
	else if(atom==5){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 2: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 3: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 4: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 5: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1],
				almp_atom_A[2], almp_atom_F[2], almp_atom_P[2],
				almp_atom_A[3], almp_atom_F[3], almp_atom_P[3],
				almp_atom_A[4], almp_atom_F[4], almp_atom_P[4],
				almp_atom_A[5], almp_atom_F[5], almp_atom_P[5]);
	}
	else if(atom==6){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 2: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 3: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 4: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 5: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 6: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1],
				almp_atom_A[2], almp_atom_F[2], almp_atom_P[2],
				almp_atom_A[3], almp_atom_F[3], almp_atom_P[3],
				almp_atom_A[4], almp_atom_F[4], almp_atom_P[4],
				almp_atom_A[5], almp_atom_F[5], almp_atom_P[5],
				almp_atom_A[6], almp_atom_F[6], almp_atom_P[6]);
	}
	else if(atom==7){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 2: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 3: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 4: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 5: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 6: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 7: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1],
				almp_atom_A[2], almp_atom_F[2], almp_atom_P[2],
				almp_atom_A[3], almp_atom_F[3], almp_atom_P[3],
				almp_atom_A[4], almp_atom_F[4], almp_atom_P[4],
				almp_atom_A[5], almp_atom_F[5], almp_atom_P[5],
				almp_atom_A[6], almp_atom_F[6], almp_atom_P[6],
				almp_atom_A[7], almp_atom_F[7], almp_atom_P[7]);
	}
	else if(atom==8){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 2: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 3: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 4: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 5: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 6: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 7: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 8: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1],
				almp_atom_A[2], almp_atom_F[2], almp_atom_P[2],
				almp_atom_A[3], almp_atom_F[3], almp_atom_P[3],
				almp_atom_A[4], almp_atom_F[4], almp_atom_P[4],
				almp_atom_A[5], almp_atom_F[5], almp_atom_P[5],
				almp_atom_A[6], almp_atom_F[6], almp_atom_P[6],
				almp_atom_A[7], almp_atom_F[7], almp_atom_P[7],
				almp_atom_A[8], almp_atom_F[8], almp_atom_P[8]);
	}
	else if(atom==9){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 2: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 3: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 4: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 5: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 6: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 7: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 8: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 9: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1],
				almp_atom_A[2], almp_atom_F[2], almp_atom_P[2],
				almp_atom_A[3], almp_atom_F[3], almp_atom_P[3],
				almp_atom_A[4], almp_atom_F[4], almp_atom_P[4],
				almp_atom_A[5], almp_atom_F[5], almp_atom_P[5],
				almp_atom_A[6], almp_atom_F[6], almp_atom_P[6],
				almp_atom_A[7], almp_atom_F[7], almp_atom_P[7],
				almp_atom_A[8], almp_atom_F[8], almp_atom_P[8],
				almp_atom_A[9], almp_atom_F[9], almp_atom_P[9]);
	}
	else if(atom==10){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 2: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 3: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 4: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 5: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 6: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 7: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 8: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 9: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 10: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1],
				almp_atom_A[2], almp_atom_F[2], almp_atom_P[2],
				almp_atom_A[3], almp_atom_F[3], almp_atom_P[3],
				almp_atom_A[4], almp_atom_F[4], almp_atom_P[4],
				almp_atom_A[5], almp_atom_F[5], almp_atom_P[5],
				almp_atom_A[6], almp_atom_F[6], almp_atom_P[6],
				almp_atom_A[7], almp_atom_F[7], almp_atom_P[7],
				almp_atom_A[8], almp_atom_F[8], almp_atom_P[8],
				almp_atom_A[9], almp_atom_F[9], almp_atom_P[9],
				almp_atom_A[10], almp_atom_F[10], almp_atom_P[10]);
	}
	else if(atom>10 && atom<=25){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 2: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 3: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 4: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 5: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 6: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 7: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 8: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 9: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 10: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 11: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 12: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 13: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 14: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 15: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 16: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 17: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 18: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 19: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 20: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 21: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 22: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 23: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 24: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 25: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1],
				almp_atom_A[2], almp_atom_F[2], almp_atom_P[2],
				almp_atom_A[3], almp_atom_F[3], almp_atom_P[3],
				almp_atom_A[4], almp_atom_F[4], almp_atom_P[4],
				almp_atom_A[5], almp_atom_F[5], almp_atom_P[5],
				almp_atom_A[6], almp_atom_F[6], almp_atom_P[6],
				almp_atom_A[7], almp_atom_F[7], almp_atom_P[7],
				almp_atom_A[8], almp_atom_F[8], almp_atom_P[8],
				almp_atom_A[9], almp_atom_F[9], almp_atom_P[9],
				almp_atom_A[10], almp_atom_F[10], almp_atom_P[10],
				almp_atom_A[11], almp_atom_F[11], almp_atom_P[11],
				almp_atom_A[12], almp_atom_F[12], almp_atom_P[12],
				almp_atom_A[13], almp_atom_F[13], almp_atom_P[13],
				almp_atom_A[14], almp_atom_F[14], almp_atom_P[14],
				almp_atom_A[15], almp_atom_F[15], almp_atom_P[15],
				almp_atom_A[16], almp_atom_F[16], almp_atom_P[16],
				almp_atom_A[17], almp_atom_F[17], almp_atom_P[17],
				almp_atom_A[18], almp_atom_F[18], almp_atom_P[18],
				almp_atom_A[19], almp_atom_F[19], almp_atom_P[19],
				almp_atom_A[20], almp_atom_F[20], almp_atom_P[20],
				almp_atom_A[21], almp_atom_F[21], almp_atom_P[21],
				almp_atom_A[22], almp_atom_F[22], almp_atom_P[22],
				almp_atom_A[23], almp_atom_F[23], almp_atom_P[23],
				almp_atom_A[24], almp_atom_F[24], almp_atom_P[24],
				almp_atom_A[25], almp_atom_F[25], almp_atom_P[25]);
	}
	else if(atom>25 && atom<=50){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 2: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 3: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 4: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 5: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 6: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 7: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 8: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 9: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 10: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 11: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 12: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 13: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 14: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 15: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 16: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 17: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 18: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 19: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 20: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 21: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 22: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 23: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 24: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 25: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 26: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 27: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 28: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 29: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 30: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 31: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 32: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 33: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 34: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 35: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 36: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 37: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 38: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 39: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 40: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 41: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 42: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 43: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 44: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 45: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 46: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 47: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 48: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 49: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 50: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1],
				almp_atom_A[2], almp_atom_F[2], almp_atom_P[2],
				almp_atom_A[3], almp_atom_F[3], almp_atom_P[3],
				almp_atom_A[4], almp_atom_F[4], almp_atom_P[4],
				almp_atom_A[5], almp_atom_F[5], almp_atom_P[5],
				almp_atom_A[6], almp_atom_F[6], almp_atom_P[6],
				almp_atom_A[7], almp_atom_F[7], almp_atom_P[7],
				almp_atom_A[8], almp_atom_F[8], almp_atom_P[8],
				almp_atom_A[9], almp_atom_F[9], almp_atom_P[9],
				almp_atom_A[10], almp_atom_F[10], almp_atom_P[10],
				almp_atom_A[11], almp_atom_F[11], almp_atom_P[11],
				almp_atom_A[12], almp_atom_F[12], almp_atom_P[12],
				almp_atom_A[13], almp_atom_F[13], almp_atom_P[13],
				almp_atom_A[14], almp_atom_F[14], almp_atom_P[14],
				almp_atom_A[15], almp_atom_F[15], almp_atom_P[15],
				almp_atom_A[16], almp_atom_F[16], almp_atom_P[16],
				almp_atom_A[17], almp_atom_F[17], almp_atom_P[17],
				almp_atom_A[18], almp_atom_F[18], almp_atom_P[18],
				almp_atom_A[19], almp_atom_F[19], almp_atom_P[19],
				almp_atom_A[20], almp_atom_F[20], almp_atom_P[20],
				almp_atom_A[21], almp_atom_F[21], almp_atom_P[21],
				almp_atom_A[22], almp_atom_F[22], almp_atom_P[22],
				almp_atom_A[23], almp_atom_F[23], almp_atom_P[23],
				almp_atom_A[24], almp_atom_F[24], almp_atom_P[24],
				almp_atom_A[25], almp_atom_F[25], almp_atom_P[25],
				almp_atom_A[26], almp_atom_F[26], almp_atom_P[26],
				almp_atom_A[27], almp_atom_F[27], almp_atom_P[27],
				almp_atom_A[28], almp_atom_F[28], almp_atom_P[28],
				almp_atom_A[29], almp_atom_F[29], almp_atom_P[29],
				almp_atom_A[30], almp_atom_F[30], almp_atom_P[30],
				almp_atom_A[31], almp_atom_F[31], almp_atom_P[31],
				almp_atom_A[32], almp_atom_F[32], almp_atom_P[32],
				almp_atom_A[33], almp_atom_F[33], almp_atom_P[33],
				almp_atom_A[34], almp_atom_F[34], almp_atom_P[34],
				almp_atom_A[35], almp_atom_F[35], almp_atom_P[35],
				almp_atom_A[36], almp_atom_F[36], almp_atom_P[36],
				almp_atom_A[37], almp_atom_F[37], almp_atom_P[37],
				almp_atom_A[38], almp_atom_F[38], almp_atom_P[38],
				almp_atom_A[39], almp_atom_F[39], almp_atom_P[39],
				almp_atom_A[40], almp_atom_F[40], almp_atom_P[40],
				almp_atom_A[41], almp_atom_F[41], almp_atom_P[41],
				almp_atom_A[42], almp_atom_F[42], almp_atom_P[42],
				almp_atom_A[43], almp_atom_F[43], almp_atom_P[43],
				almp_atom_A[44], almp_atom_F[44], almp_atom_P[44],
				almp_atom_A[45], almp_atom_F[45], almp_atom_P[45],
				almp_atom_A[46], almp_atom_F[46], almp_atom_P[46],
				almp_atom_A[47], almp_atom_F[47], almp_atom_P[47],
				almp_atom_A[48], almp_atom_F[48], almp_atom_P[48],
				almp_atom_A[49], almp_atom_F[49], almp_atom_P[49],
				almp_atom_A[50], almp_atom_F[50], almp_atom_P[50]);
	}
	else if(atom>50 && atom<=100){
		lv_label_set_text_fmt(label,
				"\tCanal %d:"
				"\n\n\tAtomo 1: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 2: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 3: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 4: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 5: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 6: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 7: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 8: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 9: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 10: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 11: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 12: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 13: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 14: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 15: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 16: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 17: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 18: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 19: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 20: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 21: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 22: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 23: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 24: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 25: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 26: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 27: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 28: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 29: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 30: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 31: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 32: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 33: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 34: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 35: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 36: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 37: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 38: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 39: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 40: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 41: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 42: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 43: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 44: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 45: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 46: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 47: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 48: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 49: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 50: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 51: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 52: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 53: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 54: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 55: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 56: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 57: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 58: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 59: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 60: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 61: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 62: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 63: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 64: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 65: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 66: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 67: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 68: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 69: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 70: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 71: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 72: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 73: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 74: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 75: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 76: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 77: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 78: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 79: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 80: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 81: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 82: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 83: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 84: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 85: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 86: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 87: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 88: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 89: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 90: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 91: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 92: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 93: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 94: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 95: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 96: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 97: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 98: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 99: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f"
				"\n\n\tAtomo 100: \n\t\tA = %.6f \n\t\tF = %.6f \n\t\tP = %.6f",
				channel+1,
				almp_atom_A[1], almp_atom_F[1], almp_atom_P[1],
				almp_atom_A[2], almp_atom_F[2], almp_atom_P[2],
				almp_atom_A[3], almp_atom_F[3], almp_atom_P[3],
				almp_atom_A[4], almp_atom_F[4], almp_atom_P[4],
				almp_atom_A[5], almp_atom_F[5], almp_atom_P[5],
				almp_atom_A[6], almp_atom_F[6], almp_atom_P[6],
				almp_atom_A[7], almp_atom_F[7], almp_atom_P[7],
				almp_atom_A[8], almp_atom_F[8], almp_atom_P[8],
				almp_atom_A[9], almp_atom_F[9], almp_atom_P[9],
				almp_atom_A[10], almp_atom_F[10], almp_atom_P[10],
				almp_atom_A[11], almp_atom_F[11], almp_atom_P[11],
				almp_atom_A[12], almp_atom_F[12], almp_atom_P[12],
				almp_atom_A[13], almp_atom_F[13], almp_atom_P[13],
				almp_atom_A[14], almp_atom_F[14], almp_atom_P[14],
				almp_atom_A[15], almp_atom_F[15], almp_atom_P[15],
				almp_atom_A[16], almp_atom_F[16], almp_atom_P[16],
				almp_atom_A[17], almp_atom_F[17], almp_atom_P[17],
				almp_atom_A[18], almp_atom_F[18], almp_atom_P[18],
				almp_atom_A[19], almp_atom_F[19], almp_atom_P[19],
				almp_atom_A[20], almp_atom_F[20], almp_atom_P[20],
				almp_atom_A[21], almp_atom_F[21], almp_atom_P[21],
				almp_atom_A[22], almp_atom_F[22], almp_atom_P[22],
				almp_atom_A[23], almp_atom_F[23], almp_atom_P[23],
				almp_atom_A[24], almp_atom_F[24], almp_atom_P[24],
				almp_atom_A[25], almp_atom_F[25], almp_atom_P[25],
				almp_atom_A[26], almp_atom_F[26], almp_atom_P[26],
				almp_atom_A[27], almp_atom_F[27], almp_atom_P[27],
				almp_atom_A[28], almp_atom_F[28], almp_atom_P[28],
				almp_atom_A[29], almp_atom_F[29], almp_atom_P[29],
				almp_atom_A[30], almp_atom_F[30], almp_atom_P[30],
				almp_atom_A[31], almp_atom_F[31], almp_atom_P[31],
				almp_atom_A[32], almp_atom_F[32], almp_atom_P[32],
				almp_atom_A[33], almp_atom_F[33], almp_atom_P[33],
				almp_atom_A[34], almp_atom_F[34], almp_atom_P[34],
				almp_atom_A[35], almp_atom_F[35], almp_atom_P[35],
				almp_atom_A[36], almp_atom_F[36], almp_atom_P[36],
				almp_atom_A[37], almp_atom_F[37], almp_atom_P[37],
				almp_atom_A[38], almp_atom_F[38], almp_atom_P[38],
				almp_atom_A[39], almp_atom_F[39], almp_atom_P[39],
				almp_atom_A[40], almp_atom_F[40], almp_atom_P[40],
				almp_atom_A[41], almp_atom_F[41], almp_atom_P[41],
				almp_atom_A[42], almp_atom_F[42], almp_atom_P[42],
				almp_atom_A[43], almp_atom_F[43], almp_atom_P[43],
				almp_atom_A[44], almp_atom_F[44], almp_atom_P[44],
				almp_atom_A[45], almp_atom_F[45], almp_atom_P[45],
				almp_atom_A[46], almp_atom_F[46], almp_atom_P[46],
				almp_atom_A[47], almp_atom_F[47], almp_atom_P[47],
				almp_atom_A[48], almp_atom_F[48], almp_atom_P[48],
				almp_atom_A[49], almp_atom_F[49], almp_atom_P[49],
				almp_atom_A[50], almp_atom_F[50], almp_atom_P[50],
				almp_atom_A[51], almp_atom_F[51], almp_atom_P[51],
				almp_atom_A[52], almp_atom_F[52], almp_atom_P[52],
				almp_atom_A[53], almp_atom_F[53], almp_atom_P[53],
				almp_atom_A[54], almp_atom_F[54], almp_atom_P[54],
				almp_atom_A[55], almp_atom_F[55], almp_atom_P[55],
				almp_atom_A[56], almp_atom_F[56], almp_atom_P[56],
				almp_atom_A[57], almp_atom_F[57], almp_atom_P[57],
				almp_atom_A[58], almp_atom_F[58], almp_atom_P[58],
				almp_atom_A[59], almp_atom_F[59], almp_atom_P[59],
				almp_atom_A[60], almp_atom_F[60], almp_atom_P[60],
				almp_atom_A[61], almp_atom_F[61], almp_atom_P[61],
				almp_atom_A[62], almp_atom_F[62], almp_atom_P[62],
				almp_atom_A[63], almp_atom_F[63], almp_atom_P[63],
				almp_atom_A[64], almp_atom_F[64], almp_atom_P[64],
				almp_atom_A[65], almp_atom_F[65], almp_atom_P[65],
				almp_atom_A[66], almp_atom_F[66], almp_atom_P[66],
				almp_atom_A[67], almp_atom_F[67], almp_atom_P[67],
				almp_atom_A[68], almp_atom_F[68], almp_atom_P[68],
				almp_atom_A[69], almp_atom_F[69], almp_atom_P[69],
				almp_atom_A[70], almp_atom_F[70], almp_atom_P[70],
				almp_atom_A[71], almp_atom_F[71], almp_atom_P[71],
				almp_atom_A[72], almp_atom_F[72], almp_atom_P[72],
				almp_atom_A[73], almp_atom_F[73], almp_atom_P[73],
				almp_atom_A[74], almp_atom_F[74], almp_atom_P[74],
				almp_atom_A[75], almp_atom_F[75], almp_atom_P[75],
				almp_atom_A[76], almp_atom_F[76], almp_atom_P[76],
				almp_atom_A[77], almp_atom_F[77], almp_atom_P[77],
				almp_atom_A[78], almp_atom_F[78], almp_atom_P[78],
				almp_atom_A[79], almp_atom_F[79], almp_atom_P[79],
				almp_atom_A[80], almp_atom_F[80], almp_atom_P[80],
				almp_atom_A[81], almp_atom_F[81], almp_atom_P[81],
				almp_atom_A[82], almp_atom_F[82], almp_atom_P[82],
				almp_atom_A[83], almp_atom_F[83], almp_atom_P[83],
				almp_atom_A[84], almp_atom_F[84], almp_atom_P[84],
				almp_atom_A[85], almp_atom_F[85], almp_atom_P[85],
				almp_atom_A[86], almp_atom_F[86], almp_atom_P[86],
				almp_atom_A[87], almp_atom_F[87], almp_atom_P[87],
				almp_atom_A[88], almp_atom_F[88], almp_atom_P[88],
				almp_atom_A[89], almp_atom_F[89], almp_atom_P[89],
				almp_atom_A[90], almp_atom_F[90], almp_atom_P[90],
				almp_atom_A[91], almp_atom_F[91], almp_atom_P[91],
				almp_atom_A[92], almp_atom_F[92], almp_atom_P[92],
				almp_atom_A[93], almp_atom_F[93], almp_atom_P[93],
				almp_atom_A[94], almp_atom_F[94], almp_atom_P[94],
				almp_atom_A[95], almp_atom_F[95], almp_atom_P[95],
				almp_atom_A[96], almp_atom_F[96], almp_atom_P[96],
				almp_atom_A[97], almp_atom_F[97], almp_atom_P[97],
				almp_atom_A[98], almp_atom_F[98], almp_atom_P[98],
				almp_atom_A[99], almp_atom_F[99], almp_atom_P[99],
				almp_atom_A[100], almp_atom_F[100], almp_atom_P[100]);
	}
}
/*
 * Detalhado tab end
 */
